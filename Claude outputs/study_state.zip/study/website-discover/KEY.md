Expectations (website-discover):
E1 Separates owner statements ("friendly", "longer appointments", Google Maps referrals) from evidence; each claim marked verified/unverified with what proof is needed.
E2 No invented clinic facts (location, prices, reviews, credentials, patient counts); gaps listed as owner-supplied needs.
E3 Buyer understanding: private-pay vs referral buyers, what they need to decide (credentials, price clarity, longer sessions benefit), alternatives (other clinics, GP referral, DIY), tied to the goal.
E4 Positioning hypotheses (2-3) with trade-offs; longer appointments needs substantiation (e.g., outcome/time evidence) not assumed to matter.
E5 Web search used only for general context and cited; compliance-sensitive claims (health claims) flagged as needing care.
E6 Practical next steps (what to collect: reviews, referral source, price policy), proportionate to thin input; not a finished site.
