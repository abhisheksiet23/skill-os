# PlanPilot — operating model inputs (founder)
Price: $120 per account per month, billed monthly. Gross margin 70% (after hosting, support tools).
Monthly logo churn: 6%. CAC: $900 per new account (paid acquisition + sales time).
Founder's claim: "LTV/CAC is 11x, payback is 3 months."
Delivery: one customer-success manager (CSM) costs $4,500/month fully loaded and can handle 40 accounts. CSM cost is NOT included in the 70% gross margin.
Plan: add 20 new accounts per month starting with 0 accounts; no upfront payments; CAC is paid at signup.
Cash today: $60,000. Fixed overhead $6,000/month (founder unpaid).
