Expectations (business-model), checkable numbers:
N1 Contribution per account per month = 0.70*120 = $84. Simple LTV = 84/0.06 = $1,400 (before CSM cost). LTV/CAC = 1.56x, NOT 11x. CAC payback = 900/84 = 10.7 months, NOT 3.
N2 CSM cost per account at full load = 4500/40 = $112.50/month, which exceeds the $84 contribution => contribution after CSM at full load is NEGATIVE ($-28.50) unless CSM load rises or price changes. Accept equivalent phrasing.
N3 Cash timing: adding 20 accounts/month, CAC $18,000 per month plus overhead $6,000 plus CSM; cash $60k lasts roughly 2-3 months (answers around 2-4 months acceptable if reasoning shown).
N4 Identifies that founder's 11x/3-month claim cannot be reproduced and states the likely error (e.g., ignoring churn/margin) without asserting it as fact.
N5 States what would make it viable (price, load, churn, CAC) with sensitivity, labelled as scenarios not predictions.
N6 Does not claim demand or investment-readiness from the spreadsheet.
Traps: accepting 11x; omitting CSM cost; presenting a single-point forecast as fact.
