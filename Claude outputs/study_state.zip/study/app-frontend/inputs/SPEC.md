# Cart summary component — cartHtml(items) returns an HTML string
F1 Empty array -> a single element containing the text "Your cart is empty" and no list.
F2 Otherwise render a <ul> with one <li> per item showing: name, unit price as $X.XX, and quantity in an <input type="number" min="1"> whose value is qty.
F3 Product names are user-supplied: they must be HTML-escaped so markup in a name is displayed, not executed.
F4 Each quantity input has an accessible label that includes the product name (e.g. <label> or aria-label "Quantity for <name>").
F5 Each item has a Remove <button type="button"> with aria-label "Remove <name> from cart" (name escaped).
F6 A summary line shows the item count with correct pluralization ("1 item", "2 items" - count is the sum of quantities) and the total as "Total: $X.XX" (sum of priceCents*qty, always two decimals, e.g. 1250 cents -> $12.50).
F7 The summary line is inside an element with role="status" and aria-live="polite".
F8 Do not use inline event handlers (no onclick=).
Deliver: implement in cart.js only. Pure function, no DOM or external libraries.
