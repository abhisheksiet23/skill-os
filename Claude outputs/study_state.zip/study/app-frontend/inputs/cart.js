// Cart summary component. Implement cartHtml(items) and export it (CommonJS).
// items: array of {id: string, name: string, priceCents: int, qty: int}
function cartHtml(items) {
  throw new Error("not implemented");
}
module.exports = { cartHtml };
