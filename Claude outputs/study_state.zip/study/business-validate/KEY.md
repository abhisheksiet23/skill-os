Expectations (business-validate):
E1 Leads with a learning decision (stop/reshape/test/proceed) rather than a generic essay; says NOT validated.
E2 Separates stated interest (friends, nods) from behavioral evidence; flags relationship bias; no invented interviews/results.
E3 Test is falsifiable: hypothesis, eligible audience and exposure denominator, measured action (commitment/deposit), threshold with reason (not a bare quota), time/cost bound, inconclusive outcome, next decision.
E4 Notes buyer vs user distinction; friend's employer pilot labelled as biased/non-generalizing.
E5 Respects authorization: planning only; nothing contacted or spent.
E6 Within $300 / 3 weeks feasibility considered.
