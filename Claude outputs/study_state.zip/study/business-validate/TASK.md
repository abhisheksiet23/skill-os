Respond to the owner's ask in the brief (BRIEF.md). Write your answer (markdown) in your working directory. Do not contact anyone or spend money; do not ask the user questions.
