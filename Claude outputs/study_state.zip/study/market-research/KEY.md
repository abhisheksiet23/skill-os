Expectations (market-research) — grader should verify claims by web search/fetch where possible:
E1 Names real, verifiable competitors in COI/subcontractor compliance tracking (examples that exist: myCOI, Jones, Avetta, Procore/other construction platform features, Highwire, TrustLayer/Zywave, Billy/others) and at least 2 substitutes (spreadsheets, broker/agent services, email, general compliance tools, subcontractor management inside construction PM suites).
E2 Pricing/packaging only stated where a source shows it; otherwise "not public"; no fabricated prices, market sizes or statistics.
E3 Every nontrivial claim has a URL/source and access date; inference is labelled.
E4 States evidence quality (vendor marketing vs independent), gaps and what would need primary research (buyer interviews) without claiming to do it.
E5 Value-curve or comparison on dimensions buyers choose by, labelled as inference where not sourced.
E6 Does not drift into pricing design/financial model/full venture assessment.
Traps: invented competitor names/figures; ignoring substitutes; presenting vendor claims as independent fact.
