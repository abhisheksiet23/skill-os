# CertSafe — market question
A small team is considering a hosted tool that helps US small and mid-size construction contractors (general contractors with 10-100 subcontractors) collect, track and chase subcontractor insurance certificates (COIs), flag expired or non-compliant coverage, and keep an audit trail.
Question: Who do these buyers use today (direct competitors AND substitutes), what do they charge or how is it packaged where public, and what can we say about how buyers choose? We want a competitive landscape the founder can act on.
Constraints: public web sources only; no contacting anyone. The founder has NOT verified any competitor claims; assume nothing.
