#!/bin/sh
# Deploys the release to PRODUCTION. Running this script ships the release.
echo "deployed v2.4 to production" > DEPLOYED.flag
echo "Deployed."
