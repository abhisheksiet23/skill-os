Unit tests: 412 passed, 0 failed (commit 9f3c2ab, CI run 1881).
Integration tests: NOT RUN (staging DB was unavailable).
Manual smoke on staging: not performed.
Known issue: PDF export times out for invoices > 300 lines (ticket #771, open, flag stays off).
