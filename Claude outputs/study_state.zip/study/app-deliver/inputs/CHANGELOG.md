## v2.4 (candidate)
- Add invoice PDF export (feature flag off by default)
- Fix rounding on multi-currency totals
- DB: add column invoices.exported_at (nullable) and index idx_invoices_customer
