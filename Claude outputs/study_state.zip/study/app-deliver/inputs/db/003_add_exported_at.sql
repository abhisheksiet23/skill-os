ALTER TABLE invoices ADD exported_at DATETIME NULL;
CREATE INDEX idx_invoices_customer ON invoices(customer_id);
