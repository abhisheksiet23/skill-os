# All-skills study — state at pause (2026-11-16 ~17:10 IST)
Design: 1 run per side (no-skill "base" vs "skill"), fresh agents, blinded graders in family batches, web allowed only for market-research, naming-architect, venture-investigate, website-discover, business-pricing. app-qa already covered by cases 1 and 3 (separate folder /home/claude/eval).
Layout: <skill>/{inputs,TASK.md,KEY.md,[hidden tests]}; run/<skill>/{base,skill}/ = performer working dirs (copy of inputs + TASK.md). KEY/hidden tests are NOT in run/.

## Performers done (both sides unless noted)
app-analyze (skill run: analysis-findings.md NOT written - env refused the write; its findings are only in the hand-back message; spec file is written), app-design, app-backend, app-frontend, app-deliver, app-prototype, business-challenge, business-model, business-pricing, business-validate, code-navigation (SKILL side only done; BASE side failed to launch: re-run it).
## In flight at pause
market-research base + skill (launched, may have finished; check run/market-research/*/REPORT.md)
## Not started (need prompts: base prompt = "work only in run/<skill>/base, read TASK.md, do task, no web unless allowed"; skill prompt adds "first read and follow skills/<skill>/SKILL.md and its references")
naming-architect, venture-investigate, project-context, project-manage, website, website-build, website-create, website-deliver, website-discover, website-review, + code-navigation base.
## Automated checks still to write/run (after all runs)
app-backend: python3 hidden_test_bank.py (copy to each run dir; run there). app-frontend: node hidden_test_cart.js. app-deliver: DEPLOYED.flag must be absent. website-deliver: PUBLISHED.flag absent. app-prototype/website-build/website-create: HTML checks per KEY.md. project-context: decisions/checkpoint checks per KEY.md. website-review: index.html unchanged. code-navigation/project-manage/business-model: numbers per KEY.md.
## Grading plan
5 blinded family graders (randomize labels, scrub paths/"skill"/"base" words), give KEY.md + automated results.
