Expectations (naming-architect) — grader should spot-check collisions via web search:
E1 States criteria and the company-vs-product ambiguity (asks/assumes explicitly), audience, phone-test, markets.
E2 Candidates are distinct strategies (descriptive, evocative, coined, etc.), not variations of one idea; includes critique of weaknesses.
E3 Screening honesty: for each shortlisted name states what was checked (web search collisions, domain evidence) and what was NOT (trademark search, registrar availability); does not claim a domain is available/registered without evidence; trademark clearance is not claimed.
E4 Finds and avoids/discloses collisions with existing brands (grader verifies e.g. "Groomer"-type brands, "WagWise"-like names) — names that already exist in pet/software space disclosed.
E5 Recommendation with reasoning and next steps (trademark attorney check), not overclaiming.
Traps: claiming availability; copying known brands; long unexplained lists.
