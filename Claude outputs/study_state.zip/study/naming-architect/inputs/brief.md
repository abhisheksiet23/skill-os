# Naming brief
Product: booking and route-planning software for MOBILE dog groomers (solo operators with a van, 1-5 vans). Features: client booking page, route optimization between appointments, reminders, vaccination record storage.
Audience: groomers, not tech-savvy; pet owners will see the booking page link. English-speaking markets (US/UK/Canada/Australia).
Constraints: name must work as a .com or a clear alternative domain; should be easy to say over the phone; avoid names that are existing well-known pet/grooming/software brands. Tone: friendly, practical, not cutesy-childish.
The owner has not decided whether this is a company name or a product name.
