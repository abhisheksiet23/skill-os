# Project Harbor — status as of Monday 2026-11-16 (start of day)
Deadline (client commitment): Friday 2026-12-18. Working days are Monday-Friday; no holidays or leave were provided.
Remaining days in tasks.csv are working-day estimates from each owner. Each person works on one task at a time unless stated.
Asha says: "I can work on T3 and T4 in parallel, but each will go at half speed."
AI/tool spend log (budget $1,500 total for the project): week of Oct 26: $90; Nov 2: $110; Nov 9: $160. (Spend is rising as more code is generated.)
Team cost is not tracked in this file.
