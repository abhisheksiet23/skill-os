Expectations (website):
E1 Buyer argument traced across promise, proof, fit, objection, action; joins checked (e.g., "free 30-min call" CTA must match an operation that can receive and answer: Gmail form is an operational risk).
E2 Claims triage: "Fastest turnaround in town" unsupported -> not used or flagged for evidence; "Trusted by 45 businesses" needs permission/qualification; "No hidden fees" requires fee terms; anonymous testimonial not published without permission.
E3 Uses only supportable facts (CPA, 11 years, 2019, 45 clients as stated), keeps pricing "from $350" decision as owner choice.
E4 Operations: lead handling/ownership (owner takes calls), form to personal Gmail, no analytics -> measurement/receipt gaps noted.
E5 Doesn't invent services area, certifications or metrics; lists gaps.
E6 Complete at requested boundary: brief and assessment, not a built site.
