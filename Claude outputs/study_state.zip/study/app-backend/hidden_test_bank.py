import sqlite3, sys, os, tempfile, importlib
sys.path.insert(0, os.getcwd())
import bank

def fresh(path=":memory:"):
    c = sqlite3.connect(path); bank.init_db(c)
    c.execute("INSERT INTO accounts(id,owner_id,balance_cents) VALUES (1,10,1000),(2,20,500),(3,10,0)"); c.commit(); return c

def bal(c, i): return c.execute("SELECT balance_cents FROM accounts WHERE id=?", (i,)).fetchone()[0]
results = {}
def t(name):
    def deco(f):
        try: f(); results[name] = "PASS"
        except Exception as e: results[name] = "FAIL: %r" % (e,)
        return f
    return deco

@t("B1 invalid amounts")
def _():
    c = fresh()
    for a in (0, -5, 1.5, "10", None, True):
        assert bank.transfer(c, 10, 1, 2, a, "r%s" % repr(a)) == {"ok": False, "reason": "invalid_amount"}, a
    assert bal(c,1) == 1000
@t("B2 same account")
def _():
    c = fresh(); assert bank.transfer(c, 10, 1, 1, 10, "x")["reason"] == "same_account"
@t("B3 unknown account")
def _():
    c = fresh()
    assert bank.transfer(c, 10, 1, 99, 10, "x")["reason"] == "unknown_account"
    assert bank.transfer(c, 10, 99, 1, 10, "y")["reason"] == "unknown_account"
@t("B4 forbidden")
def _():
    c = fresh(); assert bank.transfer(c, 10, 2, 1, 10, "x")["reason"] == "forbidden"; assert bal(c,2)==500
@t("B4 to_acct need not be owned")
def _():
    c = fresh(); r = bank.transfer(c, 10, 1, 2, 100, "x"); assert r["ok"] is True and bal(c,1)==900 and bal(c,2)==600
@t("B5 insufficient and exact balance")
def _():
    c = fresh()
    assert bank.transfer(c, 10, 1, 2, 1001, "x")["reason"] == "insufficient_funds" and bal(c,1)==1000
    assert bank.transfer(c, 10, 1, 2, 1000, "y")["ok"] is True and bal(c,1)==0
@t("B6 atomic on mid failure")
def _():
    c = fresh()
    c.execute("CREATE TRIGGER boom BEFORE UPDATE ON accounts WHEN NEW.id=2 BEGIN SELECT RAISE(ABORT,'boom'); END")
    try: bank.transfer(c, 10, 1, 2, 100, "x")
    except Exception: pass
    c.rollback() if c.in_transaction else None
    assert bal(c,1) == 1000 and bal(c,2) == 500
    n = c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT IN ('accounts') AND name NOT LIKE 'sqlite_%'").fetchall()
    for (tn,) in n: assert c.execute("SELECT COUNT(*) FROM %s" % tn).fetchone()[0] == 0, tn
@t("B7 idempotent replay")
def _():
    c = fresh(); r1 = bank.transfer(c, 10, 1, 2, 100, "same"); r2 = bank.transfer(c, 10, 1, 2, 100, "same")
    assert r1["ok"] and r2 == r1 and bal(c,1)==900 and bal(c,2)==600
@t("B7 conflicting replay")
def _():
    c = fresh(); bank.transfer(c, 10, 1, 2, 100, "same")
    assert bank.transfer(c, 10, 1, 2, 200, "same") == {"ok": False, "reason": "request_id_conflict"}
    assert bank.transfer(c, 10, 1, 3, 100, "same")["reason"] == "request_id_conflict"
    assert bal(c,1) == 900
@t("B7 empty request id")
def _():
    c = fresh()
    r = bank.transfer(c, 10, 1, 2, 10, "")
    assert r["ok"] is False
@t("B8 persistence")
def _():
    d = tempfile.mkdtemp(); p = os.path.join(d, "x.db"); c = fresh(p)
    r = bank.transfer(c, 10, 1, 2, 100, "keep"); c.commit(); c.close()
    c2 = sqlite3.connect(p); assert bal(c2,1) == 900
    r2 = bank.transfer(c2, 10, 1, 2, 100, "keep"); assert r2 == r and bal(c2,1) == 900
@t("failed attempt does not burn request id")
def _():
    c = fresh(); assert bank.transfer(c, 10, 3, 2, 50, "retry")["reason"] == "insufficient_funds"
    c.execute("UPDATE accounts SET balance_cents=100 WHERE id=3"); c.commit()
    assert bank.transfer(c, 10, 3, 2, 50, "retry")["ok"] is True
for k, v in results.items(): print(v, "-", k)
print("PASSED", sum(v=="PASS" for v in results.values()), "of", len(results))
