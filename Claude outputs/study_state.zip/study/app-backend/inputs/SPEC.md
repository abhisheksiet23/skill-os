# transfer(conn, actor_id, from_acct, to_acct, amount_cents, request_id)
Moves money between two accounts in one SQLite database (conn is an open sqlite3 connection, isolation default).
Returns a dict: success {"ok": True, "transfer_id": <int>}; failure {"ok": False, "reason": <code>}.
Rules:
B1 amount_cents must be an int > 0, else reason "invalid_amount".
B2 from_acct and to_acct must differ, else "same_account".
B3 Both accounts must exist, else "unknown_account".
B4 The actor must own from_acct (accounts.owner_id == actor_id), else "forbidden". Owning to_acct is not required.
B5 from_acct balance must cover the amount, else "insufficient_funds". Balances never go negative.
B6 The two balance updates and the transfer record are atomic: a failure midway leaves no partial change.
B7 Idempotent by request_id (non-empty string): repeating the same request_id with identical parameters returns the original success result and moves no money again. Repeating a request_id with different parameters returns "request_id_conflict" and changes nothing.
B8 Persist each successful transfer (transfer_id, request_id, actor, from, to, amount) so it survives reconnecting to the same database file.
Deliver: implement transfer and any schema/migration needed in bank.py/schema.sql (keep init_db(conn) working on an empty database). Do not edit other files.
