CREATE TABLE accounts (id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, balance_cents INTEGER NOT NULL CHECK (balance_cents >= 0));
