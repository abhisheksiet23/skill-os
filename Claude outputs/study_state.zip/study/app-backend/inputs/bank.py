import sqlite3

def init_db(conn):
    """Create schema. Extend this (or load additional SQL) if you need more tables."""
    with open("schema.sql") as f:
        conn.executescript(f.read())

def transfer(conn, actor_id, from_acct, to_acct, amount_cents, request_id):
    raise NotImplementedError
