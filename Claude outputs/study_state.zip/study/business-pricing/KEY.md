Expectations (business-pricing):
E1 Distinguishes provisional pricing options from validated prices; says current evidence cannot validate $15 (9 friendly stated answers, no commitment, biased sample).
E2 Notes survey stated vs behavioural; median 10 vs founder picking upper end; setup fee is unsupported/may add friction (flagged, not asserted).
E3 Competitor prices flagged as unverified/dated (2025, not rechecked) or re-checked via web with date noted.
E4 Offers pricing metric/packaging options (per user, tiered, flat) with a reason tied to buyer/value; margin math vs $2.10 cost-to-serve correct.
E5 Proposes a cheap falsifiable price test within 3 weeks with threshold and what counts as inconclusive; respects "do not contact anyone / spend" by not claiming to run it.
E6 Does not expand into a full venture/model exercise.
