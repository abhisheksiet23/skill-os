# TaskTrail — pricing question
Product: team task tracker for small agencies (5-25 people). Cost to serve: about $2.10 per user per month (hosting+support). Founder costs not included.
Competitor list prices (from their public pricing pages as noted by founder in 2025; not re-checked): Tool A $8/user/month, Tool B $12/user/month, Tool C $0 free tier then $6/user/month.
Founder's survey (9 respondents, all from the founder's LinkedIn network): "What would you pay per user per month?" answers: 5, 5, 8, 8, 10, 10, 10, 15, 20. Nobody was asked to pre-order.
Founder idea: "I'll charge $15/user/month since the top answers support it, plus a $50 setup fee."
Constraint: no customers yet; wants to launch pricing page in 3 weeks.
