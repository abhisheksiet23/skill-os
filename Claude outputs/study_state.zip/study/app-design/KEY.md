Expectations (app-design):
E1 Clear components (local store/service worker, sync queue, API changes, conflict handling) and flows (offline read, offline edit, sync, failure).
E2 Conflict policy (dispatcher vs technician edits) treated as an OWNER decision with options and consequences, not silently decided.
E3 Failure modes covered: partial sync, retries/idempotency, photo upload interruption, expired auth offline, clock skew, device shared between shifts (data from previous user), lost/stolen tablet encryption/wipe.
E4 Unknown volumes acknowledged; design says how sizing affects choices (storage quota, sync batch size) instead of inventing numbers as facts.
E5 Options compared for a consequential decision (e.g. IndexedDB+custom queue vs library; last-write-wins vs field merge vs manual resolve) with a recommendation tied to constraints.
E6 Respects constraints: existing API/SQL Server, no new vendor without approval flagged if suggested.
E7 Proportionate: not an exhaustive generic architecture; no code dump.
