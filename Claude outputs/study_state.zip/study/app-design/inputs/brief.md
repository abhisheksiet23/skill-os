# Field technician job sheets — offline support
Context: 200 technicians use a web app (Angular) on tablets, backed by a .NET API and SQL Server. Today they must be online to open or complete job sheets. Many sites have no signal for hours.
Requirements (accepted): view assigned job sheets offline; complete checklist items and add notes/photos offline; changes sync when back online; no lost work.
Constraints: keep existing API and SQL Server; no new cloud vendor without approval; tablets are shared between shifts; photos up to 5 MB each.
Unknown: number of jobs per technician per day, photos per job, how often a dispatcher edits a job while a technician is offline.
Owner notes: "Dispatchers sometimes reassign a job while the technician is offline. I haven't decided who wins if both edit."
