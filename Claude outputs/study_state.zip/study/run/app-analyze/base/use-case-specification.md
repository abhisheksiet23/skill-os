# Expense Approval Workflow - Use-Case Specification

Status: draft for design and test. Built from notes.md only; see analysis-findings.md for evidence (E#), assumptions (A#) and open questions (OQ#). Items marked [UNCONFIRMED] depend on an open question and must be reconfirmed before acceptance.

## 1. Scope
In: claim submission, routing, approval/rejection, status visibility, approver prompting, handoff of approved claims to the ledger, audit trail.
Out: payroll export (must not change, E6), currencies (A7), receipt enforcement (A8), multi-level chains beyond those below, SLA values.

## 2. Actors
- Employee (claimant), grade G1..Gn.
- Line approver: manager (G1-G3 claimants) or department head (G4+ claimants) (E3).
- Finance approver.
- Finance ledger clerk (receives approved claims).
- System (notifications, reminders).
- Administrator (maintains thresholds and routing parameters).

## 3. Business rules
| ID | Rule | Source |
|----|------|--------|
| BR1 | Claim amount = total of the claim, in one currency | A2, A7 |
| BR2 | Finance threshold T is a configurable parameter, default 200 [UNCONFIRMED] | E1, E2, A1 |
| BR3 | Claim total <= T: line approver approves alone | E1, E2 |
| BR4 | Claim total > T: line approver approves first, then Finance approves; both required [UNCONFIRMED: replace vs add] | E2, A3 |
| BR5 | Line approver: manager for G1-G3 claimants; department head for G4+ | E3, A4 |
| BR6 | No user may approve or reject their own claim, directly or by delegate | E5 |
| BR7 | Own-claim routing: claim by an approver goes to that person's next level up (manager's claim to department head; department head's claim to Finance). If the next approver would also be the claimant, route to Finance; if the claimant is Finance, route to another Finance user [UNCONFIRMED] | E5, A6 |
| BR8 | Auto-approve below configurable amount A (default disabled; legacy value 50) [UNCONFIRMED]. If enabled, auto-approved claims are flagged "auto-approved" in audit trail, and BR6/BR7 do not apply | E4, A5 |
| BR9 | Reject requires a reason; employee may edit and resubmit, creating a new approval round | assumed |
| BR10 | Approved claims are passed to the ledger without manual re-keying; each claim passed once | E7 |
| BR11 | Every state change records actor, time, decision, comment | assumed (audit rules, E2) |
| BR12 | The payroll export format and content are unchanged by this workflow | E6 |
| BR13 | Claim states: Draft, Submitted, Pending Line Approval, Pending Finance, Approved, Rejected, Withdrawn, Posted to Ledger | derived |
| BR14 | Threshold boundary: amount exactly T is not escalated | E1, E2 |

## 4. Use cases

### UC1 Submit claim
Actor: Employee. Pre: signed in; claim has amount > 0, date, category/description.
Main flow: 1 Employee completes and submits. 2 System validates. 3 System determines route (BR3-BR8). 4 System sets state and notifies the approver (UC6). 5 Employee sees status (UC7).
Alternates: A1 Validation fails: not submitted, errors shown. A2 Auto-approve applies (BR8): state Approved, go to UC5. A3 No eligible approver found: route to Finance (BR7); if none exists, claim stays Submitted and Administrator is alerted.
Post: claim routed, audit entry written.
Acceptance: AC1.1 claim of exactly T routes to line approver only. AC1.2 claim of T+0.01 routes to line then Finance. AC1.3 G3 claimant routes to manager, G4 claimant to department head. AC1.4 invalid claim is not saved as submitted.

### UC2 Line approver decides
Actor: line approver. Pre: claim Pending Line Approval, approver is not the claimant.
Main flow: 1 Approver opens claim from queue or notification. 2 Approves. 3 If total <= T state Approved (UC5); else state Pending Finance and Finance notified.
Alternates: A1 Reject with reason: state Rejected, employee notified (UC4). A2 Approver is claimant: action blocked (BR6).
Acceptance: AC2.1 self-approval attempt is refused and logged. AC2.2 rejection without reason is refused. AC2.3 decision recorded with actor and time.

### UC3 Finance approver decides
Actor: Finance approver. Pre: claim Pending Finance (or routed to Finance by BR7), approver is not the claimant.
Main flow: Approve leads to Approved (UC5). Reject with reason leads to Rejected.
Acceptance: AC3.1 Finance user cannot approve own claim. AC3.2 a claim over T cannot reach Approved without a Finance decision.

### UC4 Reject and resubmit
Employee is notified with reason; may edit and resubmit (UC1, new round, history retained) or withdraw (state Withdrawn). Acceptance: AC4.1 history of earlier rounds remains visible.

### UC5 Hand approved claim to ledger
Actor: System, ledger clerk. Pre: state Approved.
Main flow: 1 System makes the approved claim available to the ledger in the agreed format. 2 State becomes Posted to Ledger on confirmation. Alternates: A1 Ledger interface fails: claim stays Approved, retry, clerk alerted. Ledger interface unknown (OQ7); until defined, a Finance export of approved, unposted claims is the fallback.
Acceptance: AC5.1 no claim is passed twice. AC5.2 rejected or pending claims are never passed. AC5.3 payroll export output is identical before and after release for the same data (BR12).

### UC6 Prompt approver
Actor: System. Pending claims appear in the approver's queue and trigger a notification; reminders are sent while a claim remains pending. Reminder interval is a parameter; value not determined (no SLA). Acceptance: AC6.1 notification not the only channel: queue lists all pending claims. AC6.2 reminder fires after configured interval. AC6.3 approver absence handling: not determined (OQ9).

### UC7 View claim status
Actor: Employee. Employee sees own claims with current state, current approver role, history and rejection reasons. Acceptance: AC7.1 status changes visible without contacting Finance. AC7.2 employee sees only own claims.

### UC8 Maintain routing parameters
Actor: Administrator. Sets T, A (auto-approve, enable flag), reminder interval, grade-to-approver mapping. Changes apply to claims submitted after the change; changes are audited. Acceptance: AC8.1 changing T changes routing of the next claim, not of claims already routed.

## 5. Coverage matrix
| Requirement | UC | Status |
|-------------|----|--------|
| Manager/Finance amount rule (E1/E2) | UC1, UC2, UC3 | covered, threshold unconfirmed |
| Grade-based approver (E3) | UC1, UC2 | covered, amounts absent |
| Auto-approve < $50 (E4) | UC1 A2, UC8 | covered as option, off |
| No self-approval (E5) | UC1, UC2, UC3 | covered, approver partly assumed |
| Payroll export unchanged (E6) | UC5 | covered as regression test |
| Missed emails (E7) | UC6 | covered |
| Status visibility (E7) | UC7 | covered |
| Ledger re-keying (E7) | UC5 | covered, interface unknown |

## 6. Test data guidance
Use T=200 and also run the suite at T=500 (parameter). Amount cases: 49.99, 50, 50.01, 199.99, 200, 200.01, 499.99, 500, 500.01. Claimants: G1, G3, G4, a manager, a department head, a Finance user, a user with no manager. Run each with auto-approve off, and on at 50 (49.99 auto-approved, 50 not: boundary [UNCONFIRMED]).

## 7. Gap register
| ID | Gap | Impact | Linked |
|----|-----|--------|--------|
| G1 | Threshold $200 vs $500 | Routing and compliance | OQ1, BR2 |
| G2 | Finance replaces or adds to line approver | State model | OQ2, BR4 |
| G3 | Grade limits have no amounts | Routing | OQ3, BR5 |
| G4 | Auto-approve intent | Control risk | OQ4, BR8 |
| G5 | Approver of own claims by managers, heads, Finance | Routing | OQ5, BR7 |
| G6 | Payroll export format and relation to expenses | Regression baseline | OQ6, BR12 |
| G7 | Ledger interface | UC5 design | OQ7 |
| G8 | Currencies, receipts, SLA, volumes | Validation, reminders, sizing | OQ8 |
| G9 | Delegation, resubmission rules, audit retention | UC2, UC4, BR11 | OQ9 |
| G10 | Limit per claim, line or cumulative; split-claim detection | Control | OQ10 |
