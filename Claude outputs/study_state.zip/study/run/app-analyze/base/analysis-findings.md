# Expense Approval Workflow - Analysis Findings

Source: notes.md only (one email each from Priya and Dan, HR handbook extract, support observation, ops request, scope note, 4 interviews). No stakeholder was consulted. Dates of emails: 3 Mar and 19 Mar (year not stated).

## 1. Summary
The notes support a workflow in which an employee submits a claim, it is routed to an approver by rule, approved or rejected, status is visible to the employee, and approved claims reach the ledger without re-keying. The routing rules cannot be finalized: the notes give two conflicting money thresholds, a grade-based rule with no amounts, an unconfirmed auto-approve behavior, and no approver for managers' own claims. Those conflicts are the main blocker for design and test.

## 2. Evidence inventory
| ID | Source | Statement | Type |
|----|--------|-----------|------|
| E1 | Priya, Finance Director, 3 Mar | Managers approve up to $500; above goes to Finance | Stated rule, stakeholder email |
| E2 | Dan, Controller, 19 Mar | Over $200 needs Finance sign-off, per new audit rules | Stated rule, stakeholder email, later date |
| E3 | HR handbook 2024 | G1-G3: manager approves; G4+: department head approves; no amounts | Stated policy, partial |
| E4 | Support observation | Legacy auto-approves claims under $50; intent unconfirmed | Observed behavior, unvalidated |
| E5 | Ops request | A manager's own claim must not be self-approved; approver unspecified | Stated constraint, incomplete |
| E6 | Scope note | Payroll export format must not change | Constraint |
| E7 | 4 interviews | Approvers miss emails; employees lack status visibility; Finance re-keys approved claims into ledger | Pain points (small sample) |
| E8 | Notes | Not provided: volumes, currencies, receipt rules, multi-level approval, SLA | Declared gaps |

## 3. Findings

### F1. Conflicting Finance threshold ($500 vs $200) - blocking
E1 and E2 disagree on the amount above which Finance is involved. Dan's is later and cites audit rules, which suggests it supersedes Priya's, but the notes do not say so. Dan's wording ("over $200 needs Finance sign-off") also differs in kind: it may mean Finance signs in addition to the manager rather than instead of. Priya's wording ("goes to Finance") reads as replacing the manager. Boundary treatment: Priya says "up to $500" (inclusive); Dan says "over $200" (exclusive of 200). Both agree that exactly the limit is not escalated.
Assumption used in the spec: $200 is the working threshold (later, audit-driven), flagged as configurable and unconfirmed. Whether Finance replaces or adds to the manager is unresolved; see OQ2.

### F2. Grade-based routing has no amounts and overlaps the amount rules
E3 routes by grade (G1-G3 manager; G4+ department head) without amounts. E1/E2 route by amount (manager vs Finance) without grade. The notes do not say how the two combine. Possible reading: grade determines the first-line approver, amount determines whether Finance is added. Under this reading, the "manager" in E1 is not the approver for G4+ employees. This is an interpretation, not a stated fact. "Department head" for an employee who is already a department head is also undefined. Handbook is dated 2024 and predates Dan's "new" audit rules, so may be stale.

### F3. Auto-approve under $50 is unconfirmed and may conflict with audit rules
E4 is observed legacy behavior with no confirmation of intent. Auto-approval would bypass any approver, which sits uneasily with Dan's audit-driven tightening (E2) and with the self-approval concern (E5). Treating it as a requirement would be unsupported; omitting it would change behavior users may rely on. Decision belongs to Finance. The spec makes it an explicit configurable option, defaulting to off, pending confirmation.

### F4. Approver for managers' own claims is undefined
E5 forbids self-approval but names no approver. Candidates (not in the notes): the manager's manager, the department head, Finance. Related cases left open: a department head's own claim; a Finance approver's own claim; a claim by the top person with no superior. The prohibition should also cover indirect self-approval (delegate or Finance user approving own claim) - this is inferred from intent, not stated.

### F5. Payroll export constraint is a regression boundary
E6 means any change must leave the payroll export format byte- and field-compatible. The notes do not say whether expenses feed payroll (reimbursement through payroll is plausible but unstated) nor what the format is. Consequence: new data (e.g. status, approver) must not be added to that export; and testers need the current format as a baseline, which was not provided.

### F6. Pain points map to needs, but evidence is thin
- Missed emails: need a reliable, visible prompt for approvers (queue, reminders). Email-only notification is insufficient; the notes give no SLA, so reminder timing is unknown.
- No status visibility: need employee-visible claim status and history.
- Ledger re-keying: need an approved claim handed to the ledger without manual entry. The ledger system, interface and format are not identified.
Only 4 interviews; their roles are not stated; no measure of how often each pain occurs.

### F7. Missing information that affects the design
Volumes (sizing, notification load); currencies (threshold comparison and ledger posting need a rule for foreign amounts); receipt rules (required? above what amount? affects submission validation); multi-level approval (whether one claim can require manager and Finance sequentially, tied to F1); SLA (escalation and reminder timing). Also not stated: rejection handling and resubmission, claim withdrawal, approver absence/delegation, audit trail requirements (likely, given "audit rules"), roles with authority to configure thresholds, expense categories, split claims (several small claims to stay under a limit - a plausible control gap given thresholds).

### F8. Terminology is inconsistent
"Manager", "department head", "Finance", "Finance sign-off" are used without defined scope. "Approved up to $500" may be per claim, per line item, or cumulative per period - the notes imply per claim but do not say. The spec assumes per claim total.

## 4. Conflicts and assumptions register
| ID | Item | Spec treatment |
|----|------|----------------|
| A1 | Finance threshold is $200 (E2 over E1) | Configurable parameter, default 200, unconfirmed |
| A2 | Threshold applies to total claim amount | Assumed |
| A3 | Over-threshold claims need manager/grade approver and then Finance (sequential), not Finance only | Assumed; weakest assumption, conflicts with E1 reading |
| A4 | Grade sets first-line approver; amount adds Finance | Interpretation of E3+E1/E2 |
| A5 | Auto-approve under $50 | Off by default, configurable |
| A6 | Manager's own claim goes to their own manager; if none or if that is also the claimant, to Finance | Assumed fallback, unconfirmed |
| A7 | Single currency (amounts compared as entered) | Assumed; currency out of scope |
| A8 | Receipts not enforced by the workflow | Assumed; attachment optional |

## 5. Risks
- Wrong threshold deployed leads to either audit non-compliance ($200 true, $500 built) or unnecessary Finance load ($500 true, $200 built).
- Auto-approve could breach audit controls if retained silently.
- Payroll export regression if shared code or fields change.
- Splitting claims to evade thresholds if not detected.
- Unknown ledger interface may make the re-keying pain point only partly solvable.

## 6. Open questions (could not be determined from notes)
- OQ1. Which threshold is current: $200 or $500? Inclusive/exclusive at limit?
- OQ2. Does Finance replace or add to the line approver above threshold?
- OQ3. Amounts for grade-based limits, if any; does G4+ routing apply at all amounts?
- OQ4. Is auto-approve under $50 intended, and does it survive audit rules?
- OQ5. Who approves managers', department heads' and Finance staff's own claims?
- OQ6. Does the payroll export include expense data; what is its current format?
- OQ7. Ledger system and interface for posting approved claims.
- OQ8. Currencies, receipt rules, SLA/reminder timing, volumes.
- OQ9. Rejection/resubmission rules; delegation when approver is absent; audit retention.
- OQ10. Is the limit per claim, per line, or cumulative?

## 7. Recommendation
Proceed with design on the spec's configurable parameters, but obtain answers to OQ1, OQ2, OQ4, OQ5 before acceptance testing. Keep the payroll export untouched and capture its current output as a regression baseline.
