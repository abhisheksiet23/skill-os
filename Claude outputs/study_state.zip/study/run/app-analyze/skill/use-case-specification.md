# Use-case specification: Expense approval workflow

**Module/scope:** New expense approval workflow, increment 1 (submit, route, decide, Finance sign-off, status) plus candidate follow-on flows.
**Depth:** Standard (frames 1-5 swept; quality/environment/lifecycle recorded only where known obligations or consequential gaps exist, frames 6-9 are not exhaustively swept).
**Sources:** `notes.md` (7 items: Priya email 3 Mar, Dan email 19 Mar, HR handbook 2024 extract, legacy behavior observed by support, ops request, scope note, four interview pain points). No system access. Year of the emails not stated.
**Analysis:** [analysis-findings.md](analysis-findings.md) holds evidence and rationale. Gaps G-xx are defined only in section 7 here.
**Outcome (proposed, unconfirmed):** each claim reaches the correct approver(s) under one agreed rule, no one approves their own claim, the employee can see status, and approved claims reach Finance without re-keying. Success measure: `?` (no volumes, turnaround or SLA given).
**Responsible role:** `?` Likely Finance (Priya, Dan) and HR for grades; not confirmed.

**Reading rule:** items marked `Draft: confirm` are proposals and are not accepted behavior. Flows that depend on an open H gap are not Specified. Nothing here is Built or Verified.

## 1. Model deltas

### Actors
| Actor | Basis |
| --- | --- |
| Employee (claimant), has a grade G1 to G4+ | Handbook |
| Manager (approves G1-G3 claims) | Handbook |
| Department head (approves G4+ claims) | Handbook |
| Finance (sign-off above threshold) | Emails |
| System (routing, status, notifications, handoff) | Pain points |
| Manager as claimant of own expenses | Ops request |

Unsupported/unknown actors: delegates, administrators of thresholds/grades, claims entered on behalf of others. See G-10 and G-11.

### Entities and states
- **Claim:** claimant, grade of claimant (source of grade unknown, G-03), amount, currency `?` (G-12), receipt `?` (G-13), state, approval history.
- **Approval step:** approver, role basis (manager / department head / Finance), decision, timestamp, reason.

Proposed minimum states (`Draft: confirm`, G-07): Submitted, Awaiting approver, Awaiting Finance sign-off, Approved, Rejected. Auto-approved is a path to Approved only if G-04 is confirmed. Return-for-correction, withdrawn and paid states are unknown.

### External/time events and responding use cases
| Event | Responder |
| --- | --- |
| Employee submits a claim | UC-01 |
| Claim needs an approver | UC-02 |
| Approver decides | UC-03 |
| Claim exceeds Finance threshold | UC-04 |
| Approver does not act (time) | UC-06 (response unknown, G-06) |
| Claim approved | UC-07 |
| Claimant is their own approver | UC-02.A1 |

### Rules
| Rule | Statement | Standing |
| --- | --- | --- |
| R-01 Finance threshold | Claims above a threshold need Finance sign-off. Value and boundary: unknown (G-01) | Conflict, not set |
| R-02 First-line approver by grade | G1-G3: manager approves; G4+: department head approves | Evidence: handbook; interaction with R-01 unknown (G-02) |
| R-03 No self-approval | A claim must not be approved by its claimant. The alternate approver is unknown (G-05) | Requested by ops; scope beyond managers `Draft: confirm` |
| R-04 Payroll export unchanged | The payroll export format must not change. See C-01 | Confirmed (scope note) |
| R-05 Auto-approval | Claims under $50 auto-approved in legacy | Unconfirmed, not required (G-04) |
| R-06 Audit history | Each decision is recorded with actor, time, outcome | `Draft: confirm` (audit rules cited by Dan, content unknown, G-14) |

## 2. Sparse coverage

Operations: Create, Read, Edit, Archive, Search, Import/Export, Audit, Permissions. No baseline is confirmed, so no `✓` can be claimed. Symbols: UC reference, rule reference, `?` gap, `–` confirmed N/A.

| Entity | Create | Read | Edit | Archive | Search | Import/Export | Audit | Permissions |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Claim | UC-01 | UC-05 (claimant); approvers via UC-03; Finance via UC-04 | ? (G-15) | ? (G-14) | ? | ? (see below) | R-06 | R-02, R-03, G-11 |
| Approval step | UC-02 | UC-05 | – (decisions not edited after the fact) `Draft: confirm` | ? | ? | ? | R-06 | R-02, R-03 |

Import/export, single question (G-09): ledger handoff out of the system is needed (pain point); format, and whether payroll export carries expense data (G-08), unknown. Payroll export itself is constrained by C-01.

## 3. Use cases

### UC-01 Submit claim · Actor: Employee · Priority: Must (proposed)
Goal: submit an expense claim for approval.
Precondition: the employee is an authenticated, eligible claimant (eligibility rules unknown, G-11).
1. Employee provides the claim details (amount at minimum; other required fields unknown, G-12, G-13) and submits.
2. System validates required fields and amount.
3. System records the claim with the claimant's grade and routes it (UC-02).
4. System shows the employee the claim reference and its status (UC-05).
Done when: a claim record exists with claimant, amount and state Submitted or later; it has been routed; the employee sees a reference and status; the claimant's grade used for routing is recorded with the claim.
A1 Invalid or missing required input: reject submission, preserve entered input, state which fields are wrong. (Preserving input is `Draft: confirm`.)
A2 Claimant's grade cannot be determined: claim is not routed; employee informed; unspecified how it is resolved (G-03).
A3 Duplicate submission of the same claim: outcome unknown (G-15).
Status: Identified. Blocked by G-12, G-13, G-03 for field set and grade source.

### UC-02 Route claim · Actor: System · Priority: Must (proposed)
Goal: determine who must approve a claim.
Precondition: a valid submitted claim exists.
1. System identifies the first-line approver from the claimant's grade (R-02).
2. System determines whether Finance sign-off is also required (R-01, amount).
3. System checks the approver is not the claimant (R-03).
4. System places the claim in Awaiting approver and notifies (UC-06).
Done when: the routing outcome matches the decision table below for the claim's grade and amount, the approver is never the claimant, and the routing decision is visible in the claim's history.

Decision table (all cells depend on open decisions; shown to expose what is unknown):

| Claimant | Amount vs Finance threshold | First-line approver | Finance sign-off |
| --- | --- | --- | --- |
| G1-G3, not own approver | at or below threshold | Manager | No |
| G1-G3, not own approver | above threshold | Manager (unknown if replaced by Finance, G-02) | Yes |
| G4+, not own approver | at or below threshold | Department head | No |
| G4+, not own approver | above threshold | Department head (unknown if replaced, G-02) | Yes |
| Claimant is the designated approver (e.g. a manager, department head) | any | Unknown (G-05) | Per R-01 |
| Amount below $50 | any | Unknown if skipped (G-04) | Unknown |

"Threshold" is G-01 and "at or below" versus "above" is the boundary (G-01). Whether Finance acts after or instead of the first-line approver and whether approvals run in sequence (G-02).

A1 Claimant would be their own approver: do not route to the claimant; route to the alternate approver once defined; until defined this flow is blocked (R-03, G-05). The claim must never be approvable by its claimant.
A2 No approver can be identified (vacant manager, absent approver): outcome unknown (G-10).
A3 Amount exactly at the threshold: outcome depends on G-01.
Status: Identified, blocked (H gaps G-01, G-02, G-03, G-05).

### UC-03 Decide claim · Actor: Approver (manager or department head) · Priority: Must (proposed)
Goal: approve or reject a claim routed to them.
Precondition: the claim is Awaiting approver for this actor, and the actor is not the claimant.
1. Approver opens the claim.
2. Approver approves or rejects (reason requirement unknown, G-16).
3. System records the decision with actor and time (R-06).
4. System moves the claim: to Awaiting Finance sign-off if R-01 applies, to Approved otherwise, or to Rejected.
5. System updates the status the employee sees (UC-05).
Done when: the decision is stored once with actor and time; the claim state follows the rule above; the employee's status matches; the claimant cannot execute this flow on their own claim (server-side denial).
A1 Actor is not the assigned approver: deny, no state change.
A2 Actor is the claimant: deny, no state change, R-03.
A3 Claim already decided (concurrent decision or second click): do not record a second decision; show the existing outcome. (`Draft: confirm`.)
A4 Reject: claim becomes Rejected; whether the employee may correct and resubmit is unknown (G-17).
Status: Identified, blocked by G-01, G-02 (next state), G-16 (reason) and G-17.

### UC-04 Finance sign-off · Actor: Finance · Priority: Must (proposed)
Goal: sign off claims above the threshold.
Precondition: R-01 applies and the claim is Awaiting Finance sign-off.
1. Finance user opens the claim.
2. Finance approves or rejects.
3. System records the decision and moves the claim to Approved or Rejected.
Done when: no claim subject to R-01 reaches Approved without a Finance decision recorded; the decision has actor and time; the employee's status matches.
A1 Actor lacks Finance authority: deny, no state change.
A2 Finance and first-line approver is the same person, or Finance claimant is own approver: unknown (G-05).
A3 Finance rejects after first-line approval: claim becomes Rejected, the first-line approval stays in history.
Status: Identified, blocked by G-01, G-02. Number of Finance approvers/levels unknown (multi-level approval not provided, G-02).

### UC-05 Track status · Actor: Employee · Priority: Must (proposed, from pain point)
Goal: know the current status of own claims.
Precondition: authenticated employee with at least one claim.
1. Employee opens their claims.
2. System shows each claim's state and, where waiting, whom it waits on (disclosure of approver name `Draft: confirm`, G-07).
Done when: every claim of the employee shows a state that matches the claim record at the time of viewing, and the employee cannot see other employees' claims (scope assumption `Draft: confirm`, G-11).
A1 No claims: show an empty state, not an error.
A2 Claim just changed state: the view shows the new state on next load. Any push/refresh timing is unknown.
Status: Identified; the state set is G-07. Can proceed after the state set is accepted.

### UC-06 Notify approver · Actor: System · Priority: Should (proposed)
Goal: ensure approvers learn that a claim needs them.
Precondition: a claim has entered Awaiting approver or Awaiting Finance sign-off.
1. System notifies the approver through the chosen channel(s) (unknown, G-06).
Done when: the approver is notified for every claim that awaits them. Reminder and escalation behavior: unknown (G-06).
A1 Delivery failure: unknown.
Pain point: email alone has been missed; the channel choice is unmade (G-06). Status: Identified, blocked by G-06.

### UC-07 Hand off approved claim · Actor: System / Finance · Priority: Should (proposed)
Goal: approved claims reach the ledger without Finance re-keying.
Precondition: claim in Approved.
1. System provides the approved claim to Finance in the agreed form (unknown, G-09).
Done when: `?` Depends on ledger interface/fields, which are unknown. Failure and duplicate-handoff behavior unknown.
Status: Identified, blocked by G-09. Must not change the payroll export (C-01).

### UC-08 Auto-approve small claim · Actor: System · Priority: `?`
Legacy behavior observed (under $50). Not requested, not confirmed. Not specified. If confirmed (G-04), the flow needs: boundary at $50, interaction with R-03 and R-01, audit record, and receipt rule. Status: Identified, not in scope until G-04 is decided.

## 4. Quality, experience, manageability, constraints

| ID | Item | Target / check | Status |
| --- | --- | --- | --- |
| C-01 Payroll export | The payroll export format must not change | Check: output of the export for a fixed fixture set is identical before and after this change (field order, names, encoding, layout) | Confirmed constraint, check method proposed |
| NW-01 Access control | Approve/reject actions are enforced on the server for the assigned approver only; claimants cannot decide their own claims | Check: attempt the action as claimant and as non-assigned user; denied, no state change | Derived from R-03, categorical |
| NW-02 Auditability | Each decision and route is retained with actor, time and outcome | Check: history shows each decision. Retention period unknown | G-14 |
| NW-03 Performance, load, availability | Not stated | No target invented | G-12 (grouped quality question) |
| NX-01 Status clarity | Employee can see current state without asking | Check: UC-05 | Proposed |
| NM-01 Threshold manageability | Whether thresholds and grade mapping are changeable without release | Unknown | G-10 |

## 5. Coverage frame check

1. Actors x goals: employee, approvers, Finance, system covered. Delegation/admin unserved (G-10).
2. Goals to use cases: all pain points map to UC-05, UC-06, UC-07. UC-08 has no stated goal (unjustified until confirmed).
3. Events to responses: inaction timeout has no response (G-06); rejection-after-resubmission unknown (G-17).
4. Data: claim fields incomplete (G-12, G-13); edit/withdraw/archive unknown (G-14, G-15).
5. Rules: R-01 and R-02 conflict or lack combination (G-01, G-02); R-03 enforced in UC-02.A1 and UC-03.A2 but the fallback is open.
Frames 6-9 not swept; known obligations are in section 4. Only the gaps listed are known misses; further needs (currency, security review, migration from legacy, retention) may exist.

## 6. Tracking

Source: `notes.md`; owner: unconfirmed. Priorities are proposed.

| Flow | Priority | Status | Blocked by |
| --- | --- | --- | --- |
| UC-01 Submit claim | Must | Identified | G-12, G-13, G-03 |
| UC-02 Route claim | Must | Identified | G-01, G-02, G-03, G-05 |
| UC-03 Decide claim | Must | Identified | G-01, G-02, G-16, G-17 |
| UC-04 Finance sign-off | Must | Identified | G-01, G-02 |
| UC-05 Track status | Must | Identified | G-07 |
| UC-06 Notify approver | Should | Identified | G-06 |
| UC-07 Hand off approved claim | Should | Identified | G-09 |
| UC-08 Auto-approve | `?` | Identified | G-04 |
| C-01 Payroll export unchanged | Must | Specified (constraint and check method) | none |
| NW-01 Access control | Must | Specified | none (applies to UC-02/03/04) |

No flow is Specified, Built or Verified except the constraints noted. Specified requires no consequential unknowns; the Must use cases have H gaps. No readiness claim beyond that.

## 7. Gaps and decisions (authoritative register)

Severity: H blocks a Must flow; M changes a rule, test or scope; L detail. Standing is "needs input" unless a proposal is shown; all proposals are unconfirmed.

| Ref | Sev | Frame | Question / conflict | Affects | Owner | Proposal |
| --- | --- | --- | --- | --- | --- | --- |
| G-01 Finance threshold conflict | H | 5 | Priya (3 Mar): managers up to $500, above to Finance. Dan (19 Mar): over $200 needs Finance sign-off "per audit rules". Which value, and does the boundary amount fall under the manager or Finance? Does the threshold apply per claim or cumulative? | R-01, UC-02, UC-03, UC-04 | Finance (Priya/Dan), unconfirmed | Ask both to confirm one rule; do not build either until settled. Dan's is later and audit-based, but that is inference |
| G-02 Grade and amount combination | H | 5 | How do the handbook (grade selects approver) and the thresholds (amount adds Finance) combine? Does Finance replace or add to the first-line approver? Sequential or parallel? Multi-level approval not provided | R-01, R-02, UC-02 to 04 | Finance + HR | Needs input; reading "first-line by grade, plus Finance above threshold" is the simplest but is a guess |
| G-03 Grade source | H | 4 | Where does the claimant's grade come from, and what if missing or changed after submission? Does handbook G4+ include all grades above G3? | UC-01.A2, UC-02 | HR | Needs input |
| G-04 Auto-approval under $50 | M | 5 | Is it intended? Applies to all grades? Interacts with R-03 and audit rule | R-05, UC-08, UC-02 | Finance | Do not build until confirmed |
| G-05 Self-approval alternate | H | 5 | Who approves when the claimant is the designated approver (manager, department head, and possibly Finance)? Does the rule apply beyond managers? | R-03, UC-02.A1, UC-04.A2 | Ops + Finance | Needs input; candidate alternates: next-level approver, Finance. Not chosen |
| G-06 Notification design | M | 3 | Channel(s), reminders, escalation after inaction, delegation when approver absent. Email alone is the current failure | UC-06, UC-02.A2 | Product owner | Needs input |
| G-07 Status set and visibility | M | 4 | Final claim states, whether approver identity is shown, and whether the status shows rejection reason | UC-05, model | Product owner | Draft states in section 1 |
| G-08 Payroll coupling | M | 7 | Does expense data appear in the payroll export, or is it only adjacent? | C-01 | Finance/Payroll | Needs input; C-01 holds regardless |
| G-09 Ledger handoff | M | 7 | Ledger system, format, fields (coding), timing, failure and duplicate behavior. Is this in scope for increment 1? | UC-07 | Finance | Defer to increment 2 |
| G-10 Delegation, vacancy, configuration | M | 1 | Absent or vacant approver, delegate, and whether thresholds/grade mapping are configurable | UC-02.A2, NM-01 | Product owner | Needs input |
| G-11 Claimant eligibility and visibility scope | M | 1 | Who may submit (including on behalf of others), and who may view which claims (approvers' scope, Finance scope) | UC-01, UC-05 | Product owner | Draft: claimants see own claims only; approvers see claims routed to them |
| G-12 Currency, volumes and quality targets | M | 6 | Currencies and conversion for threshold comparison; volumes; response times; availability. None provided | UC-01, NW-03 | Product owner | Needs input; no numbers invented |
| G-13 Receipt rules | M | 4 | Required, from what amount, who checks | UC-01, UC-03 | Finance | Needs input |
| G-14 Audit and retention | M | 5 | What the "new audit rules" require of history and retention; archive of claims | R-06, NW-02 | Controller (Dan) | Needs input, rules not supplied |
| G-15 Claim edit, withdraw, duplicate | L | 4 | Can a claim be edited or withdrawn before decision? Duplicate detection | UC-01.A3, coverage | Product owner | Needs input |
| G-16 Rejection reason | L | 5 | Is a reason mandatory for reject? | UC-03 | Finance | Draft: mandatory, `Draft: confirm` |
| G-17 Resubmission after rejection | M | 3 | May the claimant correct and resubmit, and does that create a new claim or reopen? | UC-03.A4 | Product owner | Needs input |

No gap is closed. Current blockers (H): G-01, G-02, G-03, G-05; they block every Must flow except UC-05 (which needs G-07) and the constraints. Later dependencies: G-06, G-09.

### Change history
None (first version, no prior Specified flows).
