# Technical design: offline job sheets for field technicians

Status: proposal, not accepted. Input: `brief.md` (accepted requirements, constraints, unknowns, owner note). No codebase, API contract or deployed environment was available, so everything about the existing system is an assumption (section 9).

## 1. Recommendation

Extend the existing Angular app and .NET/SQL Server API. Do not add a vendor, broker or sync product.

- **Client:** make the Angular app an installable PWA. A service worker caches the app shell. A per-user IndexedDB store holds the job sheets the technician has been assigned (a cached copy) and a durable **outbox** of every change made on the device.
- **Writes:** every offline change is recorded as a small, idempotent **operation** (a checklist item set, a note added, a photo attached, a job completed). The UI reads local state first. A sync engine drains the outbox to the server when connectivity returns.
- **Server:** add one additive sync surface to the existing API. It has a `pull` endpoint (assigned jobs plus a per-job version), a `push` endpoint (a batch of operations, applied idempotently, each with its own result), and a photo upload endpoint (resumable by whole-file retry, keyed by photo ID). SQL Server stays the only authoritative store. Existing endpoints and clients are unchanged.
- **Conflicts:** operations are merged at field/item level, not per job sheet. Server-side assignment changes are always authoritative. A technician's recorded work is never silently discarded. If a job was reassigned while the tech was offline, their work is kept as a flagged record for the dispatcher to resolve (section 5, D2). That is the proposed default for the owner's undecided question; it is one policy switch in the server and can be changed.
- **Shared tablets:** local data is partitioned per user. Logout is blocked or gated while that user has unsynced work (section 5, D5).

Condition that would overturn the PWA-plus-outbox approach: a requirement for native capabilities a browser cannot give reliably (guaranteed background sync on iOS, large guaranteed storage, device-managed encryption at rest). Then a thin native/Capacitor shell around the same Angular code is the next step. The sync protocol below is unchanged by that.

## 2. Scope and what this design relies on

Accepted requirements (from the brief), with IDs used below:

- R1 view assigned job sheets offline
- R2 complete checklist items, add notes and photos offline
- R3 changes sync when back online
- R4 no lost work

Constraints: keep the existing API and SQL Server; no new cloud vendor without approval; tablets shared between shifts; photos up to 5 MB.

No use-case specification was supplied, so there are no stable flow or rule references. The R-numbers above are the only traceability handle.

## 3. Components and responsibilities

| Component | Responsibility | Owns / writes |
| --- | --- | --- |
| Service worker | Caches app shell so the app opens with no signal. Does not hold business data. | Static assets only |
| Local store (IndexedDB, per user) | Cached job sheets with their server version; outbox of operations; photo blobs awaiting upload; sync state. | Local copy only; never authoritative |
| Sync engine (Angular service) | Pulls assigned jobs; pushes outbox in order per job; retries with backoff; reports per-operation outcome to the UI; survives app restart because state is in the outbox. | Outbox state transitions |
| Job UI | Reads and writes the local store only; shows per-job and per-item sync status (pending, synced, needs attention). | None |
| Sync API (new, additive, .NET) | Authenticates and authorizes; validates each operation; applies it in a SQL transaction; records the operation ID for idempotency; returns per-operation result and current job version. | Server-side validation and conflict policy |
| SQL Server | Authoritative job, checklist, notes, photo metadata, assignment history, applied-operation log. | All authoritative data |
| Photo storage | Holds photo bytes. Location is unknown (section 9). Default: wherever photos are stored today; if none exists, a SQL Server FILESTREAM/varbinary or an on-prem file share, not a new cloud vendor. | Photo bytes, keyed by client photo ID |
| Dispatcher UI / existing endpoints | Unchanged except they must bump the job version and write assignment history (section 4.4). | Assignment |

Trust boundary: the tablet and its local store are untrusted. The server re-validates every operation against current assignment, role and job state. Nothing in the local store is taken as proof of permission.

## 4. Key flows

### 4.1 Going to work: hydrate (R1)

1. Online, at login or on a schedule, the sync engine calls `pull` with the last sync cursor.
2. Server returns the technician's currently assigned jobs (full sheet, checklist, existing notes, photo thumbnails/references) each with a monotonically increasing `jobVersion` (SQL `rowversion` or an integer incremented in the same transaction as any change), plus a list of jobs no longer assigned to them.
3. Client replaces its cached copy for jobs with no pending local operations and merges (section 4.3) for jobs that have some. It never overwrites unsynced local state.
4. Hydration scope is the technician's assigned jobs for a window (proposed: today plus next N days, N configurable). Hydrating on the way to site, on Wi-Fi, matters because signal may be absent at the site.

The sheet is only as fresh as the last pull. The UI must show "last updated at" per job so a technician knows an offline sheet may be stale.

### 4.2 Working offline (R2, R4)

1. A technician ticks an item, adds a note or attaches a photo. In one IndexedDB transaction the client updates its local copy and appends an operation to the outbox. The UI confirms only after that transaction commits. This is where "no lost work" starts: nothing is acknowledged to the user that is not durably on the device.
2. Operation shape: `opId` (client-generated UUID, the idempotency key), `jobId`, `type`, target (item ID or note ID), payload, `baseJobVersion` (the version the client had when it edited), `clientTimestamp`, `userId`, `deviceId`.
3. Photos: the client downsizes/compresses before storing (a 5 MB cap is a ceiling, not a target) and stores the blob in IndexedDB under a client-generated `photoId`. A photo operation references that ID; the bytes upload separately (4.3). Notes and checklist operations are tiny and never wait on photos.
4. App crash, tab kill or battery death mid-edit: the IndexedDB transaction either committed or did not. On restart the outbox is intact and the UI rebuilds from it.

### 4.3 Coming back online: sync (R3, R4)

```
Tablet                         Sync API                        SQL Server
  | push [op1, op2, op3] (per job, ordered)  |                      |
  |----------------------------------------->| authn/authz          |
  |                                          | BEGIN TX             |
  |                                          | seen opId? -> return stored result
  |                                          | validate + conflict rule
  |                                          | apply + insert OpLog(opId, result)
  |                                          | COMMIT               |
  |<-- per-op result: applied | duplicate | conflict(kept) | rejected, + jobVersion
  | mark outbox entries done only on result  |
  | upload photo bytes (photoId) ----------->| store; idempotent by photoId
```

- **Idempotency:** `OpLog` has a unique index on `opId`. Re-sending after a lost response returns the stored result and applies nothing twice. Scope: global per `opId`; retained at least as long as the maximum plausible offline period plus a safety margin (proposed 90 days; unknown, section 9).
- **Ordering:** operations for one job are applied in client order. Different jobs are independent. A failed or conflicted operation does not block later independent operations for the same job unless they depend on it (for example a note edit on a note whose creation was rejected).
- **Crash after commit, before the client got the response:** server state includes the op; client still has it in the outbox; the retry hits the `opId` unique index and returns the stored result. Outcome: no duplicate, no loss.
- **Crash before commit:** nothing stored; client retries; applied once.
- **Client marks an operation done only after the server's per-operation result is received.** Done entries stay for a short retention so the UI can show history, then are purged. Entries in `conflict` or `rejected` are never purged automatically.
- **Photos:** upload keyed by `photoId`; a retry of an already-stored `photoId` returns success. Upload is a separate request per photo so one failure does not block others. Client may retry the whole file; chunked/resumable upload is optional (D4). The photo operation is marked applied only when metadata is committed and bytes are stored, and the server verifies byte length/hash against the operation. A metadata row without bytes is surfaced as incomplete, not as success.
- **Retry policy:** exponential backoff with jitter, a cap on concurrent uploads (proposed 2) so 200 tablets reconnecting at shift start do not overwhelm the API or storage. After a fixed number of failures for a non-network reason (4xx), the operation moves to `needs attention` instead of retrying forever.
- **Auth while syncing:** the server authorizes at push time against the user's current account state. See D5 for token expiry while offline.

### 4.4 Reassignment while offline (the owner's open question)

Technician A is offline with job J. A dispatcher reassigns J to B, or edits J.

- Dispatcher edits and reassignments go through existing endpoints, which must (a) increment `jobVersion` and (b) write an assignment history row (job, from, to, at). Without (b) the server cannot tell on push whether A's operation was made while A was still assigned. This is an addition to existing write paths and must be confirmed as possible (section 9).
- On push from A, the server compares the operation against assignment history at the operation's `clientTimestamp` and current assignment. Policy in D2.

## 5. Consequential decisions

### D1. Offline mechanism

| Option | Fit | Cost / risk |
| --- | --- | --- |
| **A. PWA: service worker + IndexedDB + outbox, new additive sync endpoints (recommended)** | Meets R1-R4 with the current stack; no vendor; reuses auth and SQL Server. | Browser storage and background-sync limits (iOS especially); we write and own the sync engine. |
| B. Generic sync product (for example a replicated document DB or sync-as-a-service) | Mature conflict handling. | New datastore or vendor, which the constraints prohibit without approval, and a second authoritative store to reconcile with SQL Server. |
| C. Native or hybrid wrapper (Capacitor/MAUI) with SQLite | Better storage guarantees and background execution. | New build, distribution and device management; more than the stated need. Keep as the fallback. |
| D. "Better caching" of GET responses only | Cheap, covers R1. | Does not meet R2-R4 (no durable writes). |

Choose A. Revisit if tablets are iOS and storage eviction or background limits are unacceptable in the field trial (see validation, section 8).

### D2. Conflict policy (owner has not decided; proposal below, owner decision needed)

Principles regardless of choice: never silently drop work (R4); never let the offline device change assignment; make every conflict visible to a human.

| Policy | Behavior | Trade-off |
| --- | --- | --- |
| P1. Server wins entirely | Reject offline ops on changed jobs. | Violates R4 (lost work). Rejected. |
| P2. Last-write-wins by timestamp | Later edit overwrites. | Tablet clocks are unreliable; silently loses work. Rejected. |
| **P3. Field-level merge; assignment and dispatcher-owned fields server-authoritative; technician work always preserved (recommended default)** | See rules below. | Needs a dispatcher review queue and some UI. |
| P4. Manual resolution for every difference | Safest. | Heavy dispatcher workload; most conflicts are not real conflicts. |

P3 rules:

1. Data is split by who owns it. Technician-owned: checklist item results, notes, photos, completion. Dispatcher-owned: assignment, scheduled time, job instructions/definition.
2. Technician-owned edits to different items or different notes never conflict. Checklist item set twice (once by the offline tech, once on the server by someone else): the later server-recorded change wins on the value, but the other value is kept in the item's history and the job is flagged. (Whether another party can edit items at all is unknown, section 9.)
3. Dispatcher-owned fields: server value wins; the offline device never writes them.
4. **Reassignment:** if A's operations are pushed after J was reassigned to B, the server still stores A's notes/photos/item results, attributed to A with their original time, as **contributed-while-assigned** work, and marks J `needs review` for the dispatcher. It does not apply A's "job completed" transition, because B now owns the job. The client shows A that J was reassigned and that their work was kept and sent for review. Whether A's work should overwrite B's checklist state is the owner's choice (candidates: never, only for items B has not touched, or only on dispatcher approval). The default above is "stored and attributed, not applied to B's live state, until the dispatcher accepts it". This is the specific item for the owner to decide.
5. If the job was completed by someone else, or cancelled or deleted: same handling. Work kept, flagged, not applied.

The point is that the owner's undecided choice affects only a server-side rule and a review UI; the sync protocol, outbox and idempotency do not depend on it. Implementation can start with the default and the decision can follow.

### D3. Where conflict is detected: version token

Use `jobVersion` per job plus per-item row versions. Operations carry `baseJobVersion` but the server does not reject on mismatch alone (that would force whole-job conflicts); it uses the version to decide whether a field-level check is needed. Alternative of a single `ETag` on the whole job was rejected because any dispatcher edit would conflict with any technician edit.

### D4. Photo upload mechanism

| Option | Notes |
| --- | --- |
| **Single-request upload per photo with whole-file retry, photoId idempotent (recommended)** | Simple. At 5 MB or less after compression, whole-file retry is acceptable on a mobile link. |
| Chunked/resumable upload | Better on flaky links but a new protocol and server state. Add only if field data shows repeated mid-upload failures. |

Capacity is unmeasured: jobs/day and photos/job are unknown. Planning arithmetic only, clearly an estimate: if each technician took 10 photos at 5 MB, that is 50 MB per technician per day and 10 GB per day across 200 technicians (upper bound, not a forecast). Compression to roughly 1 to 2 MB would cut that by more than half. These numbers must be replaced with measurements before sizing storage.

### D5. Shared tablets, identity and storage

- **Per-user partition:** IndexedDB database name includes the user ID. User B signing in on A's tablet sees only B's data. A's unsynced outbox stays on the device under A's partition until A signs in and syncs.
- **Logout with unsynced work:** if there is signal, sync first, then logout. If there is none, warn and allow the user to log out only if they accept that the work remains on the tablet under their account and must be synced by them later; never wipe unsynced data on logout. Never auto-wipe on a shift change.
- **Risk of stranded work:** a tech finishes a shift offline, hands over the tablet, and never signs in again. Mitigation: the next user is shown a banner "unsynced work from <name> on this device" (name only, no contents), and a dispatcher-visible report of devices with old unsynced operations. Whether syncing on behalf of A without A's credentials is acceptable is a security/owner decision (section 9); the default is that it is not. A device-scoped sync credential is the alternative if it must be.
- **Data at rest:** the tablet holds customer job data and photos. Browser storage is not encrypted by the app. Proposed: rely on device encryption via MDM, which must be confirmed; app-level encryption with a key derived from the user's login is an option but cannot work for fully offline cold start without a cached credential, so it adds complexity. Not decided (section 9).
- **Offline authentication:** the user must have signed in online at least once on this device. The token lifetime is unknown. If the token expires while offline, the user must still be able to work locally, with local reads and writes gated by "last successful login within X days" (X an owner/security choice); the sync engine re-authenticates on reconnect, and a push is rejected if the account was disabled or the user lost assignment rights. Local access control offline is convenience, not a security boundary.
- **Storage eviction:** call `navigator.storage.persist()` and monitor quota. A browser may evict origin storage under pressure, which would lose unsynced work. Mitigations: request persistence, keep a visible storage-health indicator, sync opportunistically whenever a connection exists (not only at logout), and limit hydrated window and thumbnail sizes. Persistence may not be granted on every browser; this must be tested on the real tablets.

## 6. Failure behavior

| Failure | Behavior | Durable state | Who recovers |
| --- | --- | --- | --- |
| No signal at site | App opens from cache; local read/write works. | Outbox grows | Automatic on reconnect |
| App/tablet crash mid-edit | Committed IndexedDB transaction survives; partial edits do not appear. | Outbox | Automatic on restart |
| Response lost after server commit | Retry returns stored result via `opId`. | Server has op, client re-sends | Automatic |
| Server unavailable or 5xx | Backoff retry; UI shows "waiting to sync". | Outbox | Automatic; ops on-call if prolonged |
| Operation rejected (validation, authorization) | Moved to `needs attention` with a reason; not retried. | Outbox entry retained | Technician or dispatcher |
| Photo bytes upload fails repeatedly | Photo stays in outbox, marked failed; the job's other operations proceed. | Blob in IndexedDB | Technician retries; dispatcher sees incomplete photos |
| Job reassigned or completed elsewhere | Work stored, attributed, flagged for review (D2). | Server `needs review` | Dispatcher |
| Tablet storage full or evicted | Warn before capture when low; eviction cannot be detected after the fact except by a missing outbox at next login. | Possibly lost on device | Mitigation only: early and frequent sync; this is a residual risk to R4 |
| Tablet lost or stolen with unsynced work | That work is lost and customer data is exposed unless device encryption and remote wipe exist. | Device only | Outside this design; MDM |
| Clock wrong on tablet | Ordering uses outbox sequence, not wall-clock; `clientTimestamp` is informational and used for assignment history comparison only. If the clock error is large, assignment comparison could misclassify work, so the server compares against `baseJobVersion` first and timestamps second. | n/a | Server rule |
| Client and server versions differ (old PWA cached) | Sync API versioned; the server rejects unsupported client versions with a clear "update required" while outbox is preserved; service worker update flow must not clear IndexedDB. Outbox entries carry a schema version so a new client can read old entries (migrations of local schema must be forward-compatible). | Outbox | Automatic after update |
| Reconnect storm at shift start | Concurrency cap on client; server rate limit with `Retry-After`; photos upload after operations. | Outbox | Automatic |

## 7. Data changes on SQL Server (additive only)

Proposed, to be adapted to existing schema (unknown): `JobVersion` on the job; `OpLog(opId unique, jobId, userId, deviceId, type, appliedAt, result)`; `AssignmentHistory(jobId, fromUser, toUser, at)`; `JobNeedsReview` flag/table; photo metadata gaining `clientPhotoId unique`, byte length and hash. Changes are expansion-only so the current API and any old clients keep working; existing dispatcher endpoints gain two side effects (version bump, history row) in the same transaction as their current update. Scripts must be repository-owned and idempotent per the project's conventions; this design does not run or author them. Rollback: the new columns and tables are ignorable by old code, so rolling back the app does not require rolling back the schema.

## 8. Proof and validation plan (not yet executed; nothing here has been run)

1. **Field trial on the real tablets and browser**, before building the UI at scale: confirm service worker install, IndexedDB persistence grant, storage quota, behavior after the OS/browser kills the app, and photo capture and storage of 5 MB images. This could overturn D1 (move to option C). Smallest check, decides most.
2. **Idempotency test at the API:** same push twice, same push concurrently, kill the server between commit and response; expect one applied effect and the same result.
3. **Conflict scenarios** (R4): reassign while offline then sync; dispatcher edits the same job; job completed by another user; assert work retained and flagged, assignment unchanged.
4. **Offline soak:** airplane-mode for a full shift of simulated edits and photos; restart the app repeatedly; reconnect; compare server state with the expected set (nothing lost, nothing duplicated).
5. **Shared tablet:** two users alternate with unsynced work; verify isolation and no wipe on logout.
6. **Load:** 200 simulated clients reconnecting together with a measured photo load (once workload is known).
7. **Observability:** counts of outbox age, operations in `needs attention`, `needs review` jobs, rejected ops and photo failures, per device. Healthy: outbox drains within minutes of connectivity. Degraded: growing backlog with connectivity. Stuck: entries older than a threshold (proposed 24 hours with connectivity). Sync results are also business audit records (OpLog), kept separate from diagnostic logs.

Increments (each leaves a working path): (1) PWA shell and read-only offline view with versioned pull; (2) outbox plus idempotent push for checklist and notes; (3) photos; (4) conflict handling and dispatcher review queue; (5) shared-device and hardening items. Increment 1 plus the field trial can proceed before the owner decides D2.

## 9. What could not be determined

Verified: nothing about the existing system. All of the following are assumptions or unknowns.

- **Existing code and schema:** API contract, job and checklist model, how photos are stored today, whether a row version exists, auth mechanism and token lifetime. The additive design may need adjustment; in particular, whether dispatcher write paths can record assignment history and bump a version.
- **Workload (from the brief):** jobs per technician per day, photos per job, dispatcher edit frequency while a tech is offline. Affects storage on device, hydration window, upload time, server storage and how often D2 conflicts occur. Size estimates above are illustrative only.
- **Owner decision D2:** who wins when both edit; the default is a proposal.
- **Devices:** tablet OS, browser, MDM and device encryption, storage free space, remote wipe. Drives PWA feasibility and the at-rest data risk.
- **Security/compliance:** whether job data or photos have retention, privacy or encryption requirements; whether another person may sync a departed user's work.
- **Photo storage location and capacity**, and whether it can be extended without a new vendor.
- **Whether others can edit checklist items/notes on the server** (affects the item-level conflict rule).
- **Maximum offline duration** (affects OpLog retention, token policy and hydration window).
- **Background sync:** not relied on; sync runs when the app is open, because background sync support in browsers on tablets is not verified.

Revisit points: the field trial result (D1), the owner's D2 decision, measured workload (D4 and storage), and security answers (D5).
