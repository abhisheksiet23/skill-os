# Technical design: offline job sheets for field technicians

Status: draft for review. No code. Scope: Angular web app on tablets, existing .NET API and SQL Server.

## 1. Goals and constraints

Accepted requirements: view assigned job sheets offline; complete checklist items and add notes/photos offline; sync on reconnect; no lost work.
Constraints: keep the existing API and SQL Server (treated here as: no breaking changes, additive endpoints/columns only); no new cloud vendor; shared tablets between shifts; photos up to 5 MB.
Sizing is unknown (see section 9), so the design is sized by stated assumptions and has measurable limits rather than fixed numbers.

## 2. Architecture overview

```
Angular app (PWA)
  UI components  --reads/writes-->  Offline data layer (facade)
                                      |-- Local store (IndexedDB): job sheets, outbox, photo blobs, sync state
                                      |-- Sync engine (outbox drain, pull/refresh, retries)
                                      |-- Connectivity monitor
  Service worker: app shell caching (app loads with no network)
        |  HTTPS (existing auth)
.NET API: existing endpoints + additive sync support (idempotency, version tokens, photo upload)
        |
SQL Server: existing tables + additive columns/tables (row version, change log, idempotency keys, photo metadata)
Photo bytes: SQL Server (FILESTREAM/varbinary) or existing on-prem/file storage already in use (see D5)
```

Principle: the UI never talks to the API directly for job sheets. It reads from and writes to the local store; the sync engine is the only component that talks to the server. Online and offline therefore follow one code path (local-first), which avoids a separate "offline mode" that rarely gets tested.

## 3. Components and responsibilities

| Component | Responsibility | Explicitly not responsible for |
|---|---|---|
| Service worker | Cache app shell/static assets so the app starts offline; versioned updates (activate on next safe launch, never mid-edit). | Caching API data or queuing writes (the app owns that, so behavior is testable and visible). |
| Local store (IndexedDB, per-user database) | Persist assigned job sheets, pending operations (outbox), photo blobs, per-job sync status, last-sync cursor. | Business rules. |
| Offline data facade | Single API for UI: get jobs, record checklist change, add note, attach photo. Writes locally then enqueues an operation, in one transaction. | Network. |
| Outbox / operation log | Ordered, durable list of operations per job (see 5.2). Each has a client-generated id (idempotency key), base version, status. | |
| Sync engine | Drain outbox in order, upload photos, pull fresh assignments, classify results (applied / conflict / permanent reject / retry), back off. Runs on reconnect, on app start, periodically, and on user "Sync now". | Resolving conflicts silently beyond the agreed policy. |
| Connectivity monitor | Combine navigator.onLine with an actual probe to a lightweight API health endpoint (onLine alone is unreliable on poor signal). | |
| Sync status UI | Per-job and global state: synced / pending / syncing / needs attention. Shows count and age of unsynced work; warns before logout/shift end. | |
| API: sync support | Idempotent operation endpoint, version tokens, delta pull of assigned jobs, chunked/resumable photo upload, server-side validation. | |
| SQL Server | Source of truth. Additive: row version on job sheet, operation-id table (dedupe), change log for delta pull, photo metadata. | |

## 4. Key flows

### 4.1 Go-offline preparation (while online)
1. On login and periodically while online, pull the technician's assigned jobs for the working window (default: today and next N days; N configurable) including checklist definitions, existing notes, and job-site details. Store with the server version token per job.
2. Photo thumbnails for existing photos are cached; full-size on demand only (storage).
3. UI shows "Available offline" per job, so the technician knows before driving to a dead zone. Jobs assigned after the last pull are not available; this is a stated limit, not a bug.

### 4.2 Working offline
1. Technician opens a job from the local store (no network call).
2. Each checklist tick, note, or photo: one IndexedDB transaction writes the new local state and appends an outbox operation. Only after the transaction commits does the UI show it as saved. UI marks it "pending sync".
3. Photos: resize/compress client-side to a fixed ceiling (assumed ~1.5-2 MB, original kept only if policy requires; the 5 MB limit is a hard maximum, not the target), store blob in IndexedDB, show local preview.
4. Request persistent storage (navigator.storage.persist) at first run and monitor quota; block new photos with a clear message if free quota is below a safety margin rather than failing mid-write.

### 4.3 Sync on reconnect
1. Connectivity monitor confirms real connectivity; sync engine takes a per-device lock (one tab/instance at a time, via Web Locks).
2. For each job with pending operations, in order: send operations with idempotency key + base version. Server applies in a transaction, records the operation id, returns new version, or returns a conflict with the server state.
3. Photos upload separately: metadata op first (small), blob via chunked/resumable upload, then marked complete. Photo upload failures do not block checklist/note operations for the same job.
4. After a job's operations are acknowledged, local state is replaced by the server's returned state; acknowledged operations and photo blobs are deleted locally only after the server confirms durable storage (checksum match).
5. Pull delta of assignment changes (new, changed, reassigned, removed jobs).

### 4.4 Conflict: dispatcher edits or reassigns while technician is offline
See D3. Summary: the server detects it through the version token mismatch and never silently discards technician work; it either merges non-overlapping changes or parks the technician's operations for review.

### 4.5 Shift change on a shared tablet
1. Technician A logs out. If unsynced work exists, the app warns, attempts sync, and if still offline allows logout but keeps A's data (encrypted, see D4) and marks the device "holds unsynced work for A".
2. Technician B logs in; sees only B's data. A's data is inaccessible to B.
3. When A's data can sync, it needs A's credentials/token (see D4). Fallback: the next time A logs in anywhere, sync happens there; if the tablet is never used by A again, a supervisor-run recovery path (section 7) is needed.
4. Clean-up: after confirmed sync, A's local data is wiped; stale unsynced data older than a retention limit triggers an alert instead of silent deletion.

## 5. Data design

### 5.1 Server (additive only)
- Job sheet: add row-version/ETag column (SQL Server rowversion) used as the version token.
- Operation table: operation id (GUID, unique), job id, user, device, received time, result. Gives idempotency and an audit trail.
- Field-level change tracking for conflict detection (see D3), or a simple per-section version (checklist item, notes, header fields).
- Photo metadata: id (client-generated GUID), job id, checksum, size, captured-at (device time and server receive time), upload state.
- Change feed for delta pull (modified-since cursor on assignment/job tables).

### 5.2 Client operation types
`SetChecklistItem(itemId, value, baseVersion)`, `AddNote(noteId, text)`, `AddPhoto(photoId, metadata, blobRef)`, `CompleteJob(baseVersion)`. Operations are small, append-only and idempotent by id. Notes and photos are inserts with client-generated ids, so they cannot conflict, only be orphaned (reassignment case).

## 6. Consequential decisions (options compared)

### D1. Offline mechanism
| Option | Pros | Cons |
|---|---|---|
| A. PWA: service worker for shell + IndexedDB app-managed store and outbox (recommended) | Fits existing Angular web app; no new vendor; full control of sync semantics; testable | We build and own sync logic; browser storage limits |
| B. Service-worker-only request caching + Background Sync replay of raw HTTP calls | Little app code | Hard to show status, handle conflicts or ordering; Background Sync not available on all browsers (notably iOS/Safari); opaque failures |
| C. Native/hybrid wrapper (Capacitor etc.) with SQLite and file storage | Larger, more durable storage; better background behavior | New packaging, deployment (MDM), app store/vendor concerns; larger change |
| D. Off-the-shelf sync product (PouchDB/CouchDB, cloud sync service) | Mature replication | Requires a new backend or vendor; conflicts with "keep SQL Server / no new vendor" |

Recommendation: A. Revisit C only if testing on the actual tablets shows storage eviction or photo volume that IndexedDB cannot hold reliably (unknown, section 9). Do not depend on Background Sync; sync runs when the app is open.

### D2. Sync model
| Option | Notes |
|---|---|
| Last-write-wins on whole job sheet | Simple; violates "no lost work" when dispatcher and technician both edit. Rejected. |
| Operation log with idempotent ops + base version (recommended) | Preserves each technician action; retries safe; enables field-level merge. |
| Full state replication | Heavy for photos; harder conflict semantics. |

### D3. Conflict policy (owner has not decided; this is the highest-impact open decision)
Facts: job data splits naturally into technician-owned content (checklist results, notes, photos) and dispatcher-owned content (assignee, schedule, job description, priority, checklist template).

Options:
| Option | Behavior | Risk |
|---|---|---|
| 1. Dispatcher wins always | Technician edits to changed fields discarded | Violates "no lost work"; field work wasted |
| 2. Technician wins always | Dispatcher edits overwritten | Dispatcher intent (e.g. cancellation) lost; wrong site visited |
| 3. Field-ownership merge, with manual review on true overlap (recommended default) | Technician-owned fields: technician's values are kept (notes/photos always kept as inserts). Dispatcher-owned fields: dispatcher's values win. Overlap on the same field (e.g. both changed a checklist item or job status), or reassignment: nothing is dropped, the item is flagged for review | Needs a review UI and someone responsible |
| 4. Always manual | Safe, high effort | Dispatcher workload; slow |

Reassignment sub-case (most important): if the job is reassigned away from technician T while offline and T does work on it, the server accepts T's operations as a record (work was really done) attached to the job and flags the job "work recorded by previous assignee" to the dispatcher; it does not make T the assignee again and does not delete T's work. If the job is cancelled/closed, same handling. T sees on sync: "This job was reassigned; your work was saved and sent to dispatch."
The review/flag mechanism should be built so the rule per field is configuration, so the owner's eventual decision (changing a field's winner) does not need redesign.

Decision needed from owner: confirm option 3 or pick another, and name the role that resolves flagged conflicts. Until decided, the design proceeds with option 3 as the working default, because it is the only option that satisfies "no lost work" without blocking dispatchers.

### D4. Shared tablets and data security
| Option | Notes |
|---|---|
| Single shared local database | Simple; technician B can read A's data; unsynced data tied to whichever session is open. Rejected. |
| Per-user IndexedDB, wiped on logout | Safe but loses unsynced work, violating no lost work. Rejected unless sync is guaranteed first. |
| Per-user database, encrypted at rest with a key derived from a server-issued secret/user credential, retained after logout only while unsynced (recommended) | Isolates users and protects lost/stolen devices; unsynced work survives logout |
| Server-side-only holding (force sync before logout) | Impossible offline |

Details: key material must not be stored in plaintext beside the data (a Web Crypto non-extractable key plus a user-specific secret; exact scheme is a security review item). Offline login: allow re-open with cached credentials for a bounded period (configurable, e.g. N hours/days), then require online re-auth. Photos hold customer/site data, so the same encryption applies. Sync of a logged-out user's data uses a refreshed token obtained at that user's next login (not a stored password). Whether the existing auth supports long-lived or refreshable tokens is unknown (section 9).

### D5. Photo handling and storage
- Client-side downscale/compress to a target ceiling; keep under the 5 MB limit; strip nothing needed for audit (timestamp, GPS if already collected; policy item).
- Chunked, resumable upload with checksum; retry-safe by photo GUID.
- Server storage: if the existing system stores photos in SQL Server, keep that (constraint) and size the database for growth; otherwise use existing file storage. Photo volume is unknown, so database growth should be estimated before choosing varbinary vs FILESTREAM.
- Upload order: after job operations, smallest first, so job status reaches the dispatcher before large uploads finish on weak signal.
- Storage budget: with assumptions (e.g. 8 jobs/day x 5 photos x 2 MB = 80 MB/day/technician), a 3 day window is about 240 MB. Likely OK on tablets, but must be confirmed on the actual devices/browsers.

### D6. API changes vs "keep existing API"
Interpreted as: existing endpoints remain compatible and online-only clients keep working. New: operation endpoint with idempotency key, version tokens/ETags returned by existing reads (additive header/field), delta pull endpoint, resumable photo endpoint. If the existing API cannot take any additions, the sync engine would need to replay existing calls with weaker idempotency and conflict detection; this is a fallback with materially worse guarantees and should be escalated if true.

### D7. Ordering and grouping
Operations are ordered per job, jobs are independent. Completing a job (`CompleteJob`) is sent after all checklist/note ops for that job; the server rejects completion if required checklist items are missing, and the client validates the same rule offline so the technician is told at the time of completion, not on sync.

## 7. Failure behavior

| Failure | Behavior |
|---|---|
| No signal for hours | App works fully from local store; banner shows offline and unsynced count. No data loss; sync resumes automatically. |
| Signal drops mid-sync | Operations are idempotent; resend is safe. Photos resume from the last confirmed chunk. Nothing is deleted locally before server confirmation. |
| Server returns 5xx/timeouts | Retry with exponential backoff and jitter; keep in queue; surface "needs attention" after a threshold (time or attempts). |
| Server rejects an operation (validation, 4xx) | Not retried blindly. Marked "needs attention" with reason; the operation and data stay local and visible; later operations on the same job pause, other jobs continue. Error also logged server-side for support. |
| Conflict | Per D3: no silent discard; flagged for review; technician informed. |
| Duplicate submission (retry, double tap, two tabs) | Dedupe by operation id; Web Locks prevent concurrent sync in one browser. |
| Storage quota exceeded / browser eviction | Pre-check before photo capture; warn at thresholds; request persistent storage. If data is lost anyway, detect on startup (sync-state sentinel mismatch) and report the loss to the technician and the server rather than hiding it. Mitigation: prioritise syncing photos when connectivity appears. |
| Crash or tablet battery dies mid-write | Single IndexedDB transaction for state plus outbox entry; either both exist or neither. On restart, in-progress operations are re-sent safely. |
| Token expired while offline | Work continues locally; sync requires re-authentication; app prompts for login and then syncs. Operations are not discarded for auth failure. |
| Clock wrong on tablet | Do not use device time for ordering or conflict decisions; use server receive time and per-job version. Device capture time is stored only as metadata. |
| App update while offline work pending | New service worker waits; local schema migrations are versioned and tested with non-empty outboxes; old-format operations are still understood by server. |
| Tablet lost or stolen with unsynced work | Data encrypted at rest; remote revocation of the user's tokens; the unsynced work on that device is lost (accepted residual risk; state clearly to stakeholders). |
| Technician never returns to the device | Supervisor recovery path: admin-authorised sync/export on that device; alert on unsynced data older than the retention threshold. Needs product decision. |
| Reassigned job disappears from the delta pull | Local copy retained read-only while unsynced work exists; removed after sync. |

"No lost work" is therefore guaranteed under: the browser keeps its storage, and the device is not lost before sync. Neither can be fully guaranteed by a web app; the design detects and reports violations instead of promising absolutes.

## 8. Testing and observability (design-level)
- Test with network conditions: offline for hours, flapping signal, killed app mid-write, full storage, clock skew, two users on one device, expired token.
- Server: idempotency and conflict tests with replayed and out-of-order operations.
- Telemetry: per-technician unsynced count/age, sync failure reasons, conflict rate, photo upload success and duration, local data-loss detections. Conflict rate answers the unknown in section 9 after rollout.
- Rollout: pilot with a small group of technicians and measure before the full 200.

## 9. What could not be determined (and impact)

| Unknown | Why it matters | How to handle |
|---|---|---|
| Jobs per technician per day, photos per job | Storage budget, upload time, server growth | Assumptions in D5; confirm via existing production data; pilot telemetry |
| Dispatcher edit frequency while offline | Conflict workload; whether review UI can be minimal | Query existing audit/history if available; instrument conflict rate in pilot |
| Owner's conflict decision | D3 | Option 3 working default; rules configurable; owner sign-off required |
| Who resolves flagged conflicts and how fast | Operational process | Owner to assign role |
| Tablet models, OS, browser, storage free space, MDM | IndexedDB quota/eviction, PWA install, Background Sync, native option | Device survey and test on real tablets before committing to D1-A |
| Existing authentication scheme and token lifetime | Offline login window, deferred sync after logout | Review with security/identity owner |
| Whether existing API can accept additive changes and whether schema changes are allowed | D6 | Confirm with API owners; escalate if not |
| Current photo storage location and size | D5 | Inspect |
| Security/privacy requirements (encryption at rest, retention, data-protection obligations for customer photos) | D4 | Security review |
| How many days ahead technicians need jobs available offline | Pull window and storage | Ask operations; configurable |
| Whether technicians ever edit the same job from two devices | Conflict model for one user | Assume possible; handled by version tokens |
| Existing job-sheet business rules (statuses, required fields, locking while in progress) | Op validation, whether the server already locks a job in progress | Review code and schema |
| Cost/effort and schedule | Not estimated; no basis to estimate with these unknowns | Estimate after device survey and API review |

## 10. Suggested sequence
1. Spikes: device/browser storage and photo test on real tablets; API/auth review. (Resolves the biggest unknowns cheaply.)
2. Owner decision on D3 and conflict role.
3. Server additions (idempotent operations, versions, delta pull, photo upload) with online clients unaffected.
4. Local store, outbox, sync engine; then UI status and conflict review.
5. Pilot, measure, then roll out.
