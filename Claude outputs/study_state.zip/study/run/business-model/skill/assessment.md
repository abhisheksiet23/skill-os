# PlanPilot - business model viability assessment

## Viability

**Not viable as specified.** The binding constraint is delivery cost, not demand or acquisition. Customer-success (CSM) capacity is excluded from the 70% gross margin. Once it is included, an account at full CSM load earns **-$28.50/month**. More accounts add losses, and the plan runs out of cash in **month 3**. The founder's "LTV/CAC 11x, payback 3 months" does not reproduce from the stated inputs. The model has not been tested against any customer, churn or pricing evidence, so these results are conditional on the inputs below.

## Inputs (all founder-stated; none is observed data)

| Input | Value | Status |
|---|---|---|
| Price | $120/account/month, billed monthly | Assumption, unvalidated |
| Gross margin | 70%, so $84/account/month | Assumption; excludes CSM |
| Logo churn | 6%/month, so average life 1/0.06 = 16.7 months | Assumption; no cohort data |
| CAC | $900/new account, paid at signup | Assumption |
| CSM | $4,500/month, 40 accounts each, so $112.50/account/month at full load | Stated; staffing is a step cost |
| Growth plan | +20 accounts/month from 0 | Plan; no evidence it is reachable |
| Cash / fixed | $60,000 / $6,000 per month, founder unpaid | Stated |

## 1. Unit economics

| Measure | Formula | Result |
|---|---|---|
| Contribution before CSM | 120 x 0.70 | $84.00/month |
| CSM cost per account at full load | 4,500 / 40 | $112.50/month |
| **Contribution after CSM** | 84 - 112.50 | **-$28.50/month** |
| Lifetime contribution before CSM | 84 x 16.67 | $1,400 |
| Lifetime contribution after CSM | -28.50 x 16.67 | -$475 |
| LTV/CAC before CSM | 1,400 / 900 | **1.56x** |
| LTV/CAC after CSM | -475 / 900 | **negative** |
| Simple payback before CSM | 900 / 84 | 10.7 months |
| Churn-adjusted payback before CSM | n where 84 x (1 - 0.94^n)/0.06 = 900, so 0.94^n = 0.357 | **about 16.6 months**, roughly the whole average life |
| Payback after CSM | contribution is negative | **never** |

CSM load at partial utilization is worse, because the cost per account rises as seats go unfilled. The break-even price for an account to cover its CSM at full load is 112.50 / 0.70 = **$160.71/month**. That is 34% above the current price, before any CAC or fixed cost.

### The founder's claims

- **11x LTV/CAC cannot be reproduced.** It would need lifetime contribution of 11 x 900 = $9,900. At $84/month that is 118 months of life, equal to about 0.85% monthly churn. On revenue ($120, no margin) it is 82.5 months. Even with CSM ignored, the stated inputs give 1.56x. I could not find a combination of the stated inputs that gives 11x. A likely cause is churn read as annual, or margin and CSM left out.
- **3-month payback** would need $300/month of contribution per account, or a CAC near $252 ($84 x 3). Stated payback is 10.7 months before CSM, and it never occurs after CSM.

## 2. Capacity and cash (36-month ramp, 20 new accounts/month)

Method: new accounts are billed in their signup month. Churn of 6% is applied to the opening base at month end. Billed accounts_t = opening_t + 20. CSMs are hired in whole units: ceil(billed/40) x $4,500. Net cash = billed x $84 - CSM cost - 20 x $900 - $6,000. No upfront payments, so collection is monthly with no working-capital lag assumed.

| Month | Billed accts | Gross margin | CSMs | CSM cost | CAC | Fixed | Net cash flow | Cash balance |
|---|---|---|---|---|---|---|---|---|
| 1 | 20 | 1,680 | 1 | 4,500 | 18,000 | 6,000 | -26,820 | 33,180 |
| 2 | 38.8 | 3,259 | 1 | 4,500 | 18,000 | 6,000 | -25,241 | 7,939 |
| 3 | 56.5 | 4,744 | 2 | 9,000 | 18,000 | 6,000 | -28,256 | **-20,317** |
| 6 | 103.4 | 8,684 | 3 | 13,500 | 18,000 | 6,000 | -28,816 | -106,044 |
| 12 | 174.7 | 14,674 | 5 | 22,500 | 18,000 | 6,000 | -31,826 | -288,396 |
| 36 | 297.4 | 24,982 | 8 | 36,000 | 18,000 | 6,000 | -35,018 | -1,096,380 |

- **Cash runs out in month 3.** The $60,000 funds about 2.3 months. The monthly burn is $25-35k throughout, and it does not shrink as the base grows.
- **The loss does not close with scale.** Steady-state base is 20 / 0.06 = 333 accounts. Gross margin there is 333 x 84 = $28,000/month. CSM cost needs 9 people (333 / 40 = 8.3), which is **$40,500**. CAC runs $18,000 and fixed costs $6,000. Contribution is negative before acquisition, so no volume reaches break-even.
- **Treating CSM as fractional (no step cost) does not rescue it.** Cash still turns negative in month 3 and reaches -$1.01M at month 36, so staffing granularity is not the issue.
- **The 20/month plan is capacity-consistent but loss-making.** Hiring is not the limit (about one CSM per 40 accounts is added). The issue is that each CSM costs more than the 40 accounts it supports generate.
- Independent check of month 3 by a second route: 56.5 x 120 = 6,780 revenue; x 0.70 = 4,746; minus 9,000 minus 18,000 minus 6,000 = -28,254. This agrees with the table to rounding.

## 3. What would have to change (alternative thresholds, not simultaneous)

Holding other inputs fixed, at full CSM load.

| Lever | Threshold | Basis |
|---|---|---|
| Price to cover CSM only | $160.71 | 112.50 / 0.70 |
| Price to cover CSM, CAC and fixed at steady state (333 accts; $24,000 of CAC + fixed = $72/acct) | about $265 | (112.50 + 72) / 0.70 = 263.6 |
| Accounts per CSM at $120 to cover CSM only | above 53.6 | 4,500 / 84 |
| Accounts per CSM at $120 to cover CSM, CAC and fixed at steady state | not feasible below about 375 | 84 - 4,500/N >= 72, so N >= 375 |

Reducing CAC alone or lifting acquisition volume cannot help: contribution after CSM is negative before any acquisition cost. A CSM ratio of 54+ accounts, or a price of $161+, would be needed merely to stop losing money on delivery. These are what-if levels, not demonstrated willingness to pay or demonstrated service capacity at high ratios.

## 4. Scope and limits

- All inputs are founder assertions; I have no observed churn, conversion, or retention data. Churn of 6% is treated as given, and a 6% logo churn is a hypothesis for a new product with no cohorts.
- Assumed that billing begins in signup month and churn applies at month end; a different convention changes timing by about a month but not the conclusion.
- Founder labor is unpaid, so economic cost is understated. Any founder salary would deepen the loss.
- This does not assess demand, market size, or whether 20 accounts/month is achievable. Reaching 20 per month at $900 CAC from zero is itself unproven.
- Hosting, support tools and payment fees are assumed to be inside the 70%. No refunds, bad debt or discounting are modelled.

## Implication and next observation

At the current price and ratio, every account added increases the monthly loss, and the stated $60k lasts about 2 to 3 months. The decision-relevant next observation is whether customers will pay about $160 or more (ideally $265) for a service level that needs one CSM per 40 accounts, or whether the service can be delivered at 54+ accounts per CSM. Either of these could reverse the finding. Two suggested follow-ups are `business-pricing` (willingness to pay at $160-265) and `business-validate` (observed churn and CSM time per account from a paid pilot cohort).
