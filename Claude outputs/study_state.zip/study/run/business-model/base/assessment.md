# PlanPilot viability assessment

Source: model.md (founder inputs). All figures are the founder's inputs; nothing is validated by customer data. Assumptions I added are marked (A).

## Verdict
Not viable as modeled. The founder's "11x LTV/CAC, 3-month payback" cannot be reproduced from the founder's own inputs. Once CSM cost is included, each account loses money every month, so growth increases losses. Cash runs out in month 3.

## 1. Check the founder's claim
- Gross profit per account per month = $120 x 70% = **$84**
- Expected lifetime = 1 / 6% churn = **16.7 months**
- LTV (gross-margin basis) = 84 x 16.7 = **$1,400**
- LTV/CAC = 1,400 / 900 = **1.56x** (revenue basis, ignoring margin: 2,000 / 900 = 2.2x). 11x would need an LTV of $9,900; no combination of the stated inputs gives that.
- CAC payback = 900 / 84 = **10.7 months** (revenue basis: 7.5 months). 3 months would need ~$300/month of gross profit per account. Not reproducible.

## 2. Add the cost the 70% margin omits: delivery capacity
- CSM cost per account at full utilisation = 4,500 / 40 = **$112.50/month**
- Contribution per account = 84 - 112.50 = **-$28.50/month** (negative before any CAC or overhead)
- Lifetime contribution = -28.50 x 16.7 = **-$475**; after CAC, about **-$1,375** per account acquired.
- So true LTV/CAC is negative and payback never occurs. The CSM alone costs 94% of revenue (112.5/120); with the 30% COGS, cost is 124% of revenue.
- This is the best case: CSMs are hired in whole units, so utilisation is below 100% in practice and cost per account is higher (e.g., 1 CSM for 20 accounts = $225/account).

## 3. Cash timeline (monthly model)
Method (A): accounts_t = accounts_(t-1) x 0.94 + 20; CSMs = ceil(accounts/40), hired as needed; revenue billed monthly, collected same month; CAC = 20 x $900 = $18,000 at signup; overhead $6,000; opening cash $60,000.

| Month | Accounts | CSMs | Gross profit | CSM cost | CAC | Overhead | Net cash flow | Cash end |
|---|---|---|---|---|---|---|---|---|
| 1 | 20.0 | 1 | 1,680 | 4,500 | 18,000 | 6,000 | -26,820 | 33,180 |
| 2 | 38.8 | 1 | 3,259 | 4,500 | 18,000 | 6,000 | -25,241 | 7,939 |
| 3 | 56.5 | 2 | 4,744 | 9,000 | 18,000 | 6,000 | -28,256 | **-20,317** |
| 6 | 103.4 | 3 | 8,684 | 13,500 | 18,000 | 6,000 | -28,816 | -106,044 |
| 12 | 174.7 | 5 | 14,674 | 22,500 | 18,000 | 6,000 | -31,826 | -288,396 |
| 24 | 257.8 | 7 | 21,658 | 31,500 | 18,000 | 6,000 | -33,842 | -682,809 |
| 36 | 297.4 | 8 | 24,982 | 36,000 | 18,000 | 6,000 | -35,018 | -1,096,380 |

- Cash goes negative in **month 3** (about 2.3 months of runway). It also goes negative in month 3 with fractional CSM cost, so rounding is not the cause.
- Monthly burn is ~$26-35k and does not shrink with scale: accounts plateau at 20 / 0.06 = **333**, where gross profit is $28,000 vs. CSM $40,500 (9 CSMs) + CAC $18,000 + overhead $6,000, a monthly loss of about **$36,500**.
- Even with zero new acquisition spend, an account base earns $84 and costs $112.50 to serve, so there is no steady state that pays back.
- Cumulative funding need: ~$0.3M by month 12, ~$0.7M by month 24, with no path to breakeven.

## 4. What would have to change (sensitivity, per-account, steady-state delivery)
Break-even requires contribution > 0 and LTV/CAC well above 1 (3x is a common target).

| Lever | Contribution/acct/mo | Lifetime LTV | LTV/CAC | Payback |
|---|---|---|---|---|
| As modeled | -28.50 | negative | <0 | never |
| Price $160.71 (covers CSM only) | 0 | 0 | 0 | never |
| Price $300 (GM 70%) | 97.50 | 1,625 | 1.8x | 9.2 mo |
| CSM ratio 1:100 ($45/acct), $120 | 39.00 | 650 | 0.72x | 23 mo |
| Price $200 + 1:100 | 95.00 | 1,583 | 1.76x | 9.5 mo |
| Churn 3% + 1:100, $120 | 39.00 | 1,300 | 1.44x | 23 mo |

No single lever reaches 3x. Viability needs a combination, roughly: price in the $200-300 range (or annual prepay for cash timing), CSM coverage of 1:100 or tech-touch onboarding, churn at or below 3%, and CAC well under $900.

## 5. Other observations
- Monthly billing with no upfront payment means CAC ($900) is recovered only over 10+ months even before CSM; annual prepay would fix the timing but not the negative margin.
- 6% monthly churn (about 52% annual) is high for B2B and is unvalidated; the whole LTV rests on it.
- Founder is unpaid; any salary adds to overhead and worsens the picture.
- $60k does not fund the plan even for one quarter.

## Limits
Inputs only; no demand, retention or CAC evidence was provided, so this tests internal consistency and arithmetic, not market viability. Assumptions (A): churn applied to prior-month accounts before new signups; whole-CSM hiring; revenue collected in month; no taxes or payment-processing fees beyond the 70% margin.
