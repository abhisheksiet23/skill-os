import sqlite3

def init_db(conn):
    """Create schema. Extend this (or load additional SQL) if you need more tables."""
    with open("schema.sql") as f:
        conn.executescript(f.read())

def _fail(reason):
    return {"ok": False, "reason": reason}

def transfer(conn, actor_id, from_acct, to_acct, amount_cents, request_id):
    if type(amount_cents) is not int or amount_cents <= 0:
        return _fail("invalid_amount")
    if not isinstance(request_id, str) or request_id == "":
        return _fail("invalid_request_id")
    if from_acct == to_acct:
        return _fail("same_account")

    own_txn = not conn.in_transaction
    try:
        if own_txn:
            conn.execute("BEGIN IMMEDIATE")  # take write lock before reading
        else:
            conn.execute("SAVEPOINT bank_transfer")
        result = _do_transfer(conn, actor_id, from_acct, to_acct, amount_cents, request_id)
        if result["ok"]:
            if own_txn:
                conn.commit()
            else:
                conn.execute("RELEASE bank_transfer")
        else:
            _undo(conn, own_txn)
        return result
    except BaseException:
        _undo(conn, own_txn)
        raise

def _undo(conn, own_txn):
    if own_txn:
        conn.rollback()
    else:
        conn.execute("ROLLBACK TO bank_transfer")
        conn.execute("RELEASE bank_transfer")

def _do_transfer(conn, actor_id, from_acct, to_acct, amount, request_id):
    # Idempotency first: a replay returns the original result even if the
    # balance has since changed.
    row = conn.execute(
        "SELECT id, actor_id, from_acct, to_acct, amount_cents FROM transfers WHERE request_id = ?",
        (request_id,)).fetchone()
    if row is not None:
        if tuple(row[1:]) == (actor_id, from_acct, to_acct, amount):
            return {"ok": True, "transfer_id": row[0]}
        return _fail("request_id_conflict")

    src = conn.execute("SELECT owner_id, balance_cents FROM accounts WHERE id = ?", (from_acct,)).fetchone()
    dst = conn.execute("SELECT 1 FROM accounts WHERE id = ?", (to_acct,)).fetchone()
    if src is None or dst is None:
        return _fail("unknown_account")
    if src[0] != actor_id:
        return _fail("forbidden")
    if src[1] < amount:
        return _fail("insufficient_funds")

    conn.execute("UPDATE accounts SET balance_cents = balance_cents - ? WHERE id = ?", (amount, from_acct))
    conn.execute("UPDATE accounts SET balance_cents = balance_cents + ? WHERE id = ?", (amount, to_acct))
    cur = conn.execute(
        "INSERT INTO transfers (request_id, actor_id, from_acct, to_acct, amount_cents) VALUES (?,?,?,?,?)",
        (request_id, actor_id, from_acct, to_acct, amount))
    return {"ok": True, "transfer_id": cur.lastrowid}
