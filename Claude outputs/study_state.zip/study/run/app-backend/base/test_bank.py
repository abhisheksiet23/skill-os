import sqlite3, os, tempfile, pytest
from bank import init_db, transfer

def mk(path=":memory:"):
    c = sqlite3.connect(path); init_db(c)
    c.execute("INSERT INTO accounts VALUES (1,10,100),(2,20,50),(3,10,0)"); c.commit(); return c
def bal(c): return [r[0] for r in c.execute("SELECT balance_cents FROM accounts ORDER BY id")]

def test_basic_and_rules():
    c = mk()
    assert transfer(c,10,1,2,30,"a") == {"ok":True,"transfer_id":1}
    assert bal(c)==[70,80,0]
    for args,reason in [((10,1,2,0,"b"),"invalid_amount"),((10,1,2,-1,"b"),"invalid_amount"),
        ((10,1,2,1.5,"b"),"invalid_amount"),((10,1,2,True,"b"),"invalid_amount"),((10,1,2,"5","b"),"invalid_amount"),
        ((10,1,1,5,"b"),"same_account"),((10,1,9,5,"b"),"unknown_account"),((10,9,1,5,"b"),"unknown_account"),
        ((20,1,2,5,"b"),"forbidden"),((10,1,2,71,"b"),"insufficient_funds")]:
        assert transfer(c,*args)=={"ok":False,"reason":reason}, args
    assert bal(c)==[70,80,0]
    assert transfer(c,10,1,2,70,"c")["ok"] and bal(c)==[0,150,0]  # exact balance, to_acct not owned

def test_idempotency():
    c = mk()
    r = transfer(c,10,1,2,60,"x")
    assert transfer(c,10,1,2,60,"x")==r and bal(c)==[40,110,0]  # even though 60 > ... replay ok
    assert transfer(c,10,1,2,61,"x")["reason"]=="request_id_conflict"
    assert transfer(c,10,1,3,60,"x")["reason"]=="request_id_conflict"
    assert bal(c)==[40,110,0]
    assert c.execute("SELECT count(*) FROM transfers").fetchone()[0]==1
    assert transfer(c,10,1,2,5,"")["ok"] is False

def test_replay_after_funds_gone():
    c = mk(); r = transfer(c,10,1,2,100,"x")
    assert transfer(c,10,1,2,100,"x")==r and bal(c)==[0,150,0]

def test_persistence():
    d = tempfile.mkdtemp(); p = os.path.join(d,"b.db")
    c = mk(p); r = transfer(c,10,1,2,10,"k"); c.close()
    c2 = sqlite3.connect(p)
    assert c2.execute("SELECT id,request_id,actor_id,from_acct,to_acct,amount_cents FROM transfers").fetchall()==[(r["transfer_id"],"k",10,1,2,10)]
    assert transfer(c2,10,1,2,10,"k")==r and bal(c2)==[90,60,0]
    init_db(c2)  # re-init must not wipe or fail

def test_atomic_midway_failure():
    c = mk()
    c.execute("CREATE TRIGGER boom BEFORE INSERT ON transfers BEGIN SELECT RAISE(ABORT,'boom'); END")
    with pytest.raises(sqlite3.Error): transfer(c,10,1,2,10,"z")
    assert bal(c)==[100,50,0] and not c.in_transaction
    c.execute("DROP TRIGGER boom"); assert transfer(c,10,1,2,10,"z")["ok"]

def test_inside_caller_transaction():
    c = mk(); c.execute("UPDATE accounts SET balance_cents=balance_cents WHERE id=1")
    assert c.in_transaction
    c.execute("CREATE TRIGGER boom BEFORE INSERT ON transfers BEGIN SELECT RAISE(ABORT,'boom'); END")
    with pytest.raises(sqlite3.Error): transfer(c,10,1,2,10,"z")
    assert bal(c)==[100,50,0]
    c.execute("DROP TRIGGER boom"); assert transfer(c,10,1,2,10,"z")["ok"]; c.commit(); assert bal(c)==[90,60,0]

def test_concurrent_connections():
    d = tempfile.mkdtemp(); p = os.path.join(d,"b.db"); mk(p).close()
    a = sqlite3.connect(p, timeout=5); b = sqlite3.connect(p, timeout=5)
    assert transfer(a,10,1,2,100,"p")["ok"]
    assert transfer(b,10,1,2,100,"q")["reason"]=="insufficient_funds"
