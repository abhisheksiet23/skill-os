CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, balance_cents INTEGER NOT NULL CHECK (balance_cents >= 0));
CREATE TABLE IF NOT EXISTS transfers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id TEXT NOT NULL UNIQUE CHECK (request_id <> ''),
  actor_id INTEGER NOT NULL,
  from_acct INTEGER NOT NULL REFERENCES accounts(id),
  to_acct INTEGER NOT NULL REFERENCES accounts(id),
  amount_cents INTEGER NOT NULL CHECK (amount_cents > 0)
);
