import sqlite3


def init_db(conn):
    """Create schema. Extend this (or load additional SQL) if you need more tables."""
    with open("schema.sql") as f:
        conn.executescript(f.read())


def _failure(reason):
    return {"ok": False, "reason": reason}


def _is_valid_amount(amount_cents):
    # bool is a subclass of int in Python; True must not count as 1 cent.
    if isinstance(amount_cents, bool):
        return False
    if not isinstance(amount_cents, int):
        return False
    return amount_cents > 0


def transfer(conn, actor_id, from_acct, to_acct, amount_cents, request_id):
    """Move money between two accounts. See SPEC.md rules B1-B8.

    Order of decisions:
      1. request_id must be a non-empty string (B7 precondition).
      2. Replay check: a known request_id returns the original success (same
         parameters) or "request_id_conflict" (different parameters). This comes
         before the balance check so a replay still succeeds after the money has
         since been spent.
      3. Validation and authorization (B1-B4), then funds (B5).
      4. Debit, credit and transfer record in one transaction (B6).
    """
    if not isinstance(request_id, str) or request_id == "":
        return _failure("invalid_request_id")

    # Take the write lock up front so the replay check, the balance check and the
    # updates cannot interleave with another writer on the same database file.
    # If the caller already has a transaction open, nest inside a savepoint
    # instead of committing the caller's work.
    nested = conn.in_transaction
    if nested:
        conn.execute("SAVEPOINT bank_transfer")
    else:
        conn.execute("BEGIN IMMEDIATE")

    try:
        result = _transfer_within_transaction(
            conn, actor_id, from_acct, to_acct, amount_cents, request_id
        )
    except BaseException:
        # B6: any failure midway undoes every change made by this call.
        if nested:
            conn.execute("ROLLBACK TO bank_transfer")
            conn.execute("RELEASE bank_transfer")
        else:
            conn.rollback()
        raise

    if result["ok"]:
        if nested:
            conn.execute("RELEASE bank_transfer")
        else:
            conn.commit()
    else:
        # Rejections change nothing; end the transaction we opened.
        if nested:
            conn.execute("ROLLBACK TO bank_transfer")
            conn.execute("RELEASE bank_transfer")
        else:
            conn.rollback()

    return result


def _transfer_within_transaction(conn, actor_id, from_acct, to_acct, amount_cents, request_id):
    # B7: replay or conflict.
    earlier = conn.execute(
        "SELECT id, actor_id, from_acct, to_acct, amount_cents "
        "FROM transfers WHERE request_id = ?",
        (request_id,),
    ).fetchone()

    if earlier is not None:
        earlier_id, earlier_actor, earlier_from, earlier_to, earlier_amount = earlier
        same_parameters = (
            earlier_actor == actor_id
            and earlier_from == from_acct
            and earlier_to == to_acct
            and earlier_amount == amount_cents
            and not isinstance(amount_cents, bool)
        )
        if same_parameters:
            return {"ok": True, "transfer_id": earlier_id}
        return _failure("request_id_conflict")

    # B1
    if not _is_valid_amount(amount_cents):
        return _failure("invalid_amount")

    # B2
    if from_acct == to_acct:
        return _failure("same_account")

    # B3
    source = conn.execute(
        "SELECT owner_id, balance_cents FROM accounts WHERE id = ?", (from_acct,)
    ).fetchone()
    destination = conn.execute(
        "SELECT id FROM accounts WHERE id = ?", (to_acct,)
    ).fetchone()
    if source is None or destination is None:
        return _failure("unknown_account")

    # B4
    source_owner_id, source_balance = source
    if source_owner_id != actor_id:
        return _failure("forbidden")

    # B5
    if source_balance < amount_cents:
        return _failure("insufficient_funds")

    # B6: debit, credit and record; the caller commits or rolls back all three.
    conn.execute(
        "UPDATE accounts SET balance_cents = balance_cents - ? WHERE id = ?",
        (amount_cents, from_acct),
    )
    conn.execute(
        "UPDATE accounts SET balance_cents = balance_cents + ? WHERE id = ?",
        (amount_cents, to_acct),
    )
    cursor = conn.execute(
        "INSERT INTO transfers (request_id, actor_id, from_acct, to_acct, amount_cents) "
        "VALUES (?, ?, ?, ?, ?)",
        (request_id, actor_id, from_acct, to_acct, amount_cents),
    )

    return {"ok": True, "transfer_id": cursor.lastrowid}
