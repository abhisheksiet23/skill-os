import os, sqlite3, tempfile, threading, unittest
import bank


def connect(path):
    return sqlite3.connect(path, timeout=30)


class BankTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, "bank.db")
        self.conn = connect(self.path)
        bank.init_db(self.conn)
        self.conn.execute("INSERT INTO accounts VALUES (1, 10, 1000)")
        self.conn.execute("INSERT INTO accounts VALUES (2, 20, 500)")
        self.conn.commit()

    def balances(self):
        return dict(self.conn.execute("SELECT id, balance_cents FROM accounts"))

    def count(self):
        return self.conn.execute("SELECT COUNT(*) FROM transfers").fetchone()[0]

    def test_success_and_persistence(self):
        r = bank.transfer(self.conn, 10, 1, 2, 300, "r1")
        self.assertTrue(r["ok"])
        self.assertEqual(self.balances(), {1: 700, 2: 800})
        other = connect(self.path)
        row = other.execute("SELECT id,request_id,actor_id,from_acct,to_acct,amount_cents FROM transfers").fetchone()
        self.assertEqual(row, (r["transfer_id"], "r1", 10, 1, 2, 300))
        self.assertEqual(dict(other.execute("SELECT id,balance_cents FROM accounts")), {1: 700, 2: 800})

    def test_rejections_change_nothing(self):
        cases = [
            ((10, 1, 2, 0, "a"), "invalid_amount"),
            ((10, 1, 2, -5, "b"), "invalid_amount"),
            ((10, 1, 2, 1.5, "c"), "invalid_amount"),
            ((10, 1, 2, "5", "d"), "invalid_amount"),
            ((10, 1, 2, True, "e"), "invalid_amount"),
            ((10, 1, 1, 5, "f"), "same_account"),
            ((10, 1, 99, 5, "g"), "unknown_account"),
            ((10, 99, 2, 5, "h"), "unknown_account"),
            ((20, 1, 2, 5, "i"), "forbidden"),
            ((10, 1, 2, 1001, "j"), "insufficient_funds"),
            ((10, 1, 2, 5, ""), "invalid_request_id"),
            ((10, 1, 2, 5, None), "invalid_request_id"),
        ]
        for args, reason in cases:
            self.assertEqual(bank.transfer(self.conn, *args), {"ok": False, "reason": reason}, args)
        self.assertEqual(self.balances(), {1: 1000, 2: 500})
        self.assertEqual(self.count(), 0)
        self.assertFalse(self.conn.in_transaction)

    def test_exact_balance_and_no_negative(self):
        self.assertTrue(bank.transfer(self.conn, 10, 1, 2, 1000, "all")["ok"])
        self.assertEqual(self.balances()[1], 0)
        self.assertEqual(bank.transfer(self.conn, 10, 1, 2, 1, "more")["reason"], "insufficient_funds")

    def test_credit_to_unowned_account_allowed(self):
        self.assertTrue(bank.transfer(self.conn, 10, 1, 2, 1, "x")["ok"])

    def test_idempotent_replay_even_after_funds_gone(self):
        r1 = bank.transfer(self.conn, 10, 1, 2, 1000, "k")
        r2 = bank.transfer(self.conn, 10, 1, 2, 1000, "k")
        self.assertEqual(r1, r2)
        self.assertEqual(self.balances(), {1: 0, 2: 1500})
        self.assertEqual(self.count(), 1)

    def test_request_id_conflict(self):
        bank.transfer(self.conn, 10, 1, 2, 100, "k")
        for args in [(10, 1, 2, 101), (10, 2, 1, 100), (20, 1, 2, 100), (10, 1, 3, 100)]:
            self.assertEqual(bank.transfer(self.conn, *args, "k"), {"ok": False, "reason": "request_id_conflict"})
        self.assertEqual(self.balances(), {1: 900, 2: 600})
        self.assertEqual(self.count(), 1)

    def test_failed_request_id_can_be_retried(self):
        self.assertFalse(bank.transfer(self.conn, 10, 1, 2, 5000, "k")["ok"])
        self.assertTrue(bank.transfer(self.conn, 10, 1, 2, 50, "k")["ok"])

    def test_atomic_on_midway_failure(self):
        # Make the record insert fail after both balance updates ran.
        self.conn.execute("CREATE TRIGGER boom BEFORE INSERT ON transfers BEGIN SELECT RAISE(ABORT,'boom'); END")
        self.conn.commit()
        with self.assertRaises(sqlite3.Error):
            bank.transfer(self.conn, 10, 1, 2, 100, "z")
        self.assertEqual(connect(self.path).execute("SELECT balance_cents FROM accounts ORDER BY id").fetchall(), [(1000,), (500,)])
        self.assertFalse(self.conn.in_transaction)
        # Failure on the credit step too: CHECK would not fire, so use trigger on update.
        self.conn.execute("DROP TRIGGER boom")
        self.conn.execute("CREATE TRIGGER boom2 BEFORE UPDATE ON accounts WHEN NEW.id=2 BEGIN SELECT RAISE(ABORT,'boom'); END")
        self.conn.commit()
        with self.assertRaises(sqlite3.Error):
            bank.transfer(self.conn, 10, 1, 2, 100, "z2")
        self.assertEqual(self.balances(), {1: 1000, 2: 500})

    def test_nested_in_callers_transaction(self):
        self.conn.execute("INSERT INTO accounts VALUES (3, 10, 10)")  # opens caller txn
        self.assertTrue(bank.transfer(self.conn, 10, 1, 2, 10, "n1")["ok"])
        self.assertFalse(bank.transfer(self.conn, 10, 1, 2, 99999, "n2")["ok"])
        self.conn.rollback()  # caller's rollback undoes everything incl. the transfer
        self.assertEqual(self.balances(), {1: 1000, 2: 500})
        self.assertEqual(self.count(), 0)

    def test_concurrent_distinct_requests_no_overdraft(self):
        # 20 threads each try 100 from a 1000 balance across separate connections.
        results = []
        def work(i):
            c = connect(self.path)
            results.append(bank.transfer(c, 10, 1, 2, 100, f"c{i}"))
            c.close()
        ts = [threading.Thread(target=work, args=(i,)) for i in range(20)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sum(r["ok"] for r in results), 10)
        self.assertEqual(self.balances(), {1: 0, 2: 1500})
        self.assertEqual(self.count(), 10)

    def test_concurrent_same_request_id_moves_once(self):
        results = []
        def work():
            c = connect(self.path)
            results.append(bank.transfer(c, 10, 1, 2, 100, "same"))
            c.close()
        ts = [threading.Thread(target=work) for _ in range(10)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(len({r["transfer_id"] for r in results}), 1)
        self.assertTrue(all(r["ok"] for r in results))
        self.assertEqual(self.balances(), {1: 900, 2: 600})
        self.assertEqual(self.count(), 1)


if __name__ == "__main__":
    unittest.main()
