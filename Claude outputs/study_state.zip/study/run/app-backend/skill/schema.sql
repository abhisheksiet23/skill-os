CREATE TABLE accounts (id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL, balance_cents INTEGER NOT NULL CHECK (balance_cents >= 0));


-- One row per successful transfer (B8). request_id is UNIQUE so the database itself
-- rejects a second transfer for the same request (B7), even from a concurrent writer.
CREATE TABLE transfers (
    id INTEGER PRIMARY KEY,
    request_id TEXT NOT NULL UNIQUE,
    actor_id INTEGER NOT NULL,
    from_acct INTEGER NOT NULL REFERENCES accounts(id),
    to_acct INTEGER NOT NULL REFERENCES accounts(id),
    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0)
);
