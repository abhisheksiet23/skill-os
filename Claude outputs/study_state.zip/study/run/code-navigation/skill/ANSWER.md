# Impact of changing `calc_discount` (shop/pricing.py:1)

Current signature: `calc_discount(order, rate)`. Planned: takes a customer object instead of a rate.

## Affected (must change or be re-verified)

| # | Location | Kind | Why affected |
|---|----------|------|--------------|
| 1 | shop/pricing.py:1-3 | Definition | Signature and body (`order["total"] * rate`, line 3) must change; the rate has to come from the customer. |
| 2 | shop/checkout.py:5 | Direct caller | `pricing.calc_discount(order, order.get("rate", 0.1))` passes a rate (with a 0.1 default). Needs a customer object. `finalize(order)` (line 4) has no customer in scope, so its signature or the order structure may need to change too, which could affect callers of `finalize`. None exist in this repo. |
| 3 | tests/test_pricing.py:1, 5 | Test | `calc_discount({"total": 100}, 0.1) == 10.0` uses the old (order, rate) form and will fail. Line 1 is only the import and is unaffected. |
| 4 | config/rules.yaml:2-4 | Config, by name | Rule `loyalty` has `function: calc_discount` with `args: [order, 0.15]`, a hard-coded rate. The args must become a customer. |
| 5 | shop/registry.py:6-7 | Dynamic dispatch | `getattr(pricing, "calc_" + kind)` followed by `fn(*args)` reaches `calc_discount` when `kind='discount'` (docstring, line 5). The function name never appears as a literal, so grep for the name misses it. Any `run_rule("discount", order, rate)` call would break at runtime. No such call exists in this repo. |

## Not affected (checked)

- shop/pricing.py:6 `calc_discount_legacy(total)` is a different function. It is only a name-prefix match.
- shop/reports.py:1, 5 use `calc_discount_legacy` only.
- shop/pricing.py:11 `calc_tax` is unrelated (the "vat" rule in rules.yaml:5-7 uses it).

## Confidence

- **High (about 95%) that the list is complete within this repository.** The repo has 6 files. I read every file in full and grepped for `calc_discount`, `discount`, `run_rule`, `getattr`, `yaml`, `importlib` and `eval`. Hits: 1 definition, 1 direct call, 1 test, 1 YAML entry, 1 dynamic-dispatch site.
- Nothing in the repo loads rules.yaml or calls `run_rule`, so items 4 and 5 are latent. They are affected by contract, not by a call I can trace. Whatever consumes the YAML is outside this repo.
- Not covered:
  - Code outside this repository (other services, a YAML loader, scripts, notebooks, docs) that calls `run_rule("discount", ...)`, reads rules.yaml, or imports `calc_discount`. I cannot see these.
  - Runtime-built names. `"calc_" + kind` could be built from user or config input, so a static search cannot prove which callers hit `calc_discount`.
- Method limit: no semantic tooling (Serena or a language server) was available. This is text search plus full reads only. The repo is small enough that this is adequate, but it is not a symbol-level reference check.
