#!/bin/sh
# Publishes site/ to the LIVE hosting for northgatebookkeeping.example (replaces the current live site).
echo "published $(date)" > PUBLISHED.flag
echo "Published."
