# Hosting notes
Live domain: northgatebookkeeping.example (currently serving the old WordPress site; DNS at the owner's registrar; owner has the login).
Form endpoint: https://forms.example.com/northgate forwards submissions to helen@northgate-personal.example (a personal Gmail). No spam protection configured.
No analytics installed. Old site has indexed pages: /services, /about-us, /contact.
Owner statement: "I haven't decided on the launch date. I want to see everything ready first."
