# TaskTrail pricing recommendation

## Bottom line
Launch at **$9 per user per month (annual $90/user, about 2 months free), no setup fee, with a 14-day free trial and no free tier.** Treat $9 as a **provisional launch price, not a validated one**, and run a cheap paid-commitment test during the 3 weeks before and after launch. Do not launch at $15 plus $50 setup on the current evidence.

## What the evidence is, and how much it supports
| Evidence | What it says | Reliability |
|---|---|---|
| Survey, n=9: 5, 5, 8, 8, 10, 10, 10, 15, 20 | Median $10, mean $9.67; only 2 of 9 said $15 or more; 4 of 9 said $8 or less | Low. Tiny sample, friendly LinkedIn network (biased toward the founder), hypothetical stated answers, no commitment. Stated willingness to pay usually overstates real payment. |
| Competitors: A $8, B $12, C free then $6 (2025, not re-checked) | Market anchor sits around $6-12; a free tier exists | Low to medium. A year old and unverified; list prices, not what agencies actually pay after discounts. |
| Cost to serve $2.10/user/month | Floor; any price above this is gross-margin positive | Medium (founder's estimate; excludes founder time and acquisition cost). |
| Founder's $15 claim | "Top answers support it" | Not supported. $15 is the 8th of 9 answers, and top answers are the least reliable guide. Median is $10. |

**Overall confidence:** low. The evidence is enough to rule out some options (below about $6 gives away margin and signals nothing; $15+ is above both the survey median and Tool B's $12 for an unknown, unproven product). It is not enough to pick a precise price. Roughly $8-$12 is the defensible band; where in it is untested.

## Options considered
| Option | Price | Case for | Case against | Verdict |
|---|---|---|---|---|
| A. Founder's plan | $15/user + $50 setup | Highest revenue per user if it sticks | Above Tool B ($12) with no track record; only 2 of 9 respondents named $15+; setup fee adds friction for a self-serve tool with no onboarding cost justification | Reject for launch |
| B. Match the middle | $9-10/user | Near survey median ($10) and between A ($8) and B ($12); gross margin about 77-79% | Gives up upside if true willingness to pay is higher | **Recommended ($9)** |
| C. Undercut | $6/user (match Tool C) | Easy adoption | Margin $3.90/user; trains buyers to see the product as cheap; hard to raise later | Reject |
| D. Freemium | $0 tier then paid | Competes with Tool C | Support/hosting cost on non-payers with no revenue and no customers yet to fund it; muddies the willingness-to-pay signal | Reject for now; revisit if acquisition stalls |
| E. Tiered | e.g. Starter/Team with a per-agency minimum | Captures higher-value agencies | Needs usage data to design tiers; premature with zero customers | Defer |

Why $9 over $10: it sits just above Tool A ($8) and below Tool B ($12), is close to the median, and leaves room to raise. Launching low and raising for new customers later is easier than cutting. Grandfather early customers at their launch price.

Unit economics at $9: $6.90 contribution per user per month (about 77% gross margin). A 10-person agency pays about $90/month ($81 effective on annual). Covering even a modest founder income needs a few dozen agencies, so price alone will not decide viability; acquisition will.

## Setup fee
Drop it. For a team tracker sold to 5-25 person agencies, a $50 fee is a friction point at the exact moment of conversion, there is no evidence anyone would pay it, and no cost data shows onboarding costs $50. If assisted onboarding is genuinely labor-intensive, offer it later as an optional paid service.

## How to turn this from guess into evidence (fits in 3 weeks)
1. **Re-check competitor pages now** (30 minutes, free): confirm A, B, C current prices, free-tier limits, and minimum seats.
2. **Ask for commitment, not opinions.** Go back to the 9 respondents plus new contacts outside the founder's network (target 15-20 agency owners). Show the actual pricing page at $9. Ask for a pre-order, deposit-free letter of intent, or a booked trial with a named team. Count commitments, not answers.
3. **Split-test two prices** in outreach if volume allows (for example $9 vs $12, different people). Even 10-15 conversations per arm shows direction, not significance; say so.
4. **Ask better questions:** what do you pay today and for which tool, what would be too expensive, what would make it too cheap to trust (Van Westendorp style), and who approves the spend.
5. **Decision rules set in advance:** if most serious prospects accept $9 without hesitation, test $12 for the next cohort; if many balk at $9, hold or move to $8; if none will commit at any price, the problem is demand, not pricing, and pricing work should stop.

## Confidence labels
- **Validated:** cost floor of $2.10 (founder's own figure, not independently checked).
- **Provisional:** $9/user/month, annual discount, no setup fee, 14-day trial.
- **Unvalidated hypotheses:** that $12+ is achievable; that agencies would pay a setup fee; that a free tier is needed; that per-user is the right pricing metric (per-seat is market-standard, but per-agency flat pricing was not tested).

## Limits of this work
No new data was gathered; competitor prices were not re-verified and the survey is the only willingness-to-pay input. Figures such as margins are arithmetic on the founder's stated numbers.
