# TaskTrail pricing recommendation

## Recommended test
Launch in 3 weeks with a **per-user price of $10/user/month ($8.50 effective on annual prepay), no setup fee, a 5-seat minimum, and a 14-day trial without a card**. Treat $10 as a provisional hypothesis, not a validated price. Run a **price-ladder test** on the pricing page: show $10 to most visitors and $13 to a smaller random slice. Judge by who enters a card or commits to a paid plan, not by survey answers.

Why not the founder's $15 + $50 setup: the evidence does not support it (see below), it sits above the best-known competitor (Tool B at $12), and a setup fee adds friction for an unproven product with no customers. Dropping the fee costs little: self-serve onboarding for 5-25 person teams should not need $50 of founder time.

## What the evidence supports (confidence: low)
| Evidence | What it shows | Weight |
|---|---|---|
| Survey, 9 people, answers 5,5,8,8,10,10,10,15,20 | Median $10, mean $10.11 (sum 91/9). Only 2 of 9 said 15 or more; 5 of 9 said 9 or less. | Weak. All from the founder's LinkedIn network, so friendly and probably not typical buyers. It asked a hypothetical with no commitment, which usually overstates. "Top answers support $15" cherry-picks 2 of 9. |
| Competitors: A $8, B $12, C free then $6 (founder notes, 2025, not re-checked) | Market reference is roughly $6-12. A free tier exists, so a paid-only newcomer at $15 has to explain itself. | Moderate, but possibly stale. Re-check before launch. |
| Cost to serve $2.10/user/month | Floor is far below any option, so price is a demand question, not a margin question. | Moderate. Founder time is excluded, and the figure is an estimate with no customers yet. |
| Purchases, trials, paid pilots | None exist. | No behavioral evidence at all. |

Overall: the data suggest a plausible range of about $8-12, with $10 the centre. Nothing here validates any specific price, and a $15 price is unsupported rather than refuted.

## Options compared
Shared assumptions: USD, excluding tax, cost $2.10/user/month, contribution before founder time, acquisition and fixed costs. Ordinary buyer = 10 users; heavy buyer = 25 users (top of the target range). No usage-variable cost is known beyond per-user cost.

| Option | Buyer / metric | Price | Inclusions / exclusions | Commercial risk | Evidence / test |
|---|---|---|---|---|---|
| **A. Per-user (recommended)** | Agency lead; per active user | $10/user/month; annual prepay $8.50 | All features, 5-seat minimum, 14-day trial; no setup fee; email support | Moderate: price could be too low or too high; per-seat discourages adding casual users | Price ladder, $10 vs $13 |
| B. Flat team tiers | Agency; team-size band | Up to 10 users $79; up to 25 users $179 (equal to $7.90 and $7.16 per user at full band) | Same features; band caps | Revenue per user falls at the top of each band; easy to buy, less revenue from heavy teams | Offer as an A/B variant if A converts poorly |
| C. Founder plan | Agency; per user + setup | $15/user/month + $50 setup | Same | High: 25% above Tool B, 50% above the survey median, and setup friction before value is shown | Test only as the high arm of a ladder; not as the launch price |

Bills and contribution (cost = users x $2.10):

| Buyer | Option A at $10 | Cost | Contribution | Option B | Contribution | Option C |
|---|---|---|---|---|---|---|
| Ordinary, 10 users | $100 | $21.00 | $79.00 | $79 | $58.00 | $150 + $50 setup (first month $200); contribution $129 (+$50 less onboarding time) |
| Heavy, 25 users | $250 | $52.50 | $197.50 | $179 | $126.50 | $375; contribution $322.50 |
| Small, 5 users (minimum) | $50 | $10.50 | $39.50 | n/a (band) | | $75; contribution $64.50 |

Annual prepay at $8.50 is 15% off the list price of $10. For the ordinary buyer, that is $85/month and a contribution of $64.00 (85 - 21). For the heavy buyer, it is $212.50 and $160.00 (212.50 - 52.50). The discount applies to revenue; cost does not fall. Per-user contribution at $8.50 is $6.40.

Note that Option C looks best on paper only if buyers accept it. At the survey's stated median of $10, the founder's $15 would be priced above what 7 of 9 respondents said, and each lost customer means zero contribution.

## Commercial edges (proposed owner decisions, not approved terms)
- **Billable unit:** an active user in the billing month; add or remove users at any time, prorated. Decide whether read-only guests are free (suggested: yes, to encourage adoption, as long as cost stays low).
- **Minimum:** 5 seats ($50/month) to cover support cost per account.
- **Support:** email only, included. No setup or migration service at launch. If asked, sell it as a separate quoted add-on later rather than building it into the price.
- **Discounts:** annual prepay 15% only. No custom discounts until at least 10 paying accounts. Founder is the only negotiator.
- **Renewal:** the price held for the first 12 months for early adopters. State this plainly so a "launch price" is not mistaken for the sustainable price.
- **Free tier:** do not launch one; Tool C has one, so say clearly why the trial is enough. Revisit if trial-to-paid is weak and the cause is access, not price.

## Test design
Setup: pricing page with $10 and $13 arms (random 80/20 split, same product and copy), 14-day trial, card or invoice commitment to continue. Do not message anyone new or spend money to drive traffic; use the founder's existing channels and organic traffic only, which limits volume.

Record: visitors per arm, trial starts, trial-to-paid, seat count, stated reason when a trial lapses, support hours per account.

- **Success (keep $10, try higher):** at least 5 paying agencies in 8 weeks within 5-25 seats, and the $13 arm converts at 70% or more of the $10 rate.
- **Hold at $10:** the $13 arm converts below 70% of the $10 rate.
- **Failure (revisit price or packaging):** under 20% of qualified trials convert at $10, with "too expensive" in a majority of the lapse reasons. Consider the Option B tiers or $8.
- **Guardrail:** support time over 1 hour per account per month would put the $2.10 cost estimate in doubt and requires recomputing contribution.
- Small samples: with few trials, differences between arms will be noise. Read the result as direction, not proof.

## Caveats and gaps
- Competitor prices are from 2025 and unchecked; re-check before launch (this review did not re-verify them).
- Founder's time is excluded. Even at $79 contribution per 10-seat account, covering any founder salary needs many accounts; run `business-model` before relying on this price for viability.
- Survey respondents are not confirmed buyers; `business-validate` would add stronger demand evidence (for example, 5-10 conversations with agency owners ending in a paid-pilot ask).
- Nothing was sent to anyone or spent; the test is a design, not authorization to publish or charge.

## Next actions
1. Re-check Tool A, B and C public prices this week.
2. Build the pricing page with the $10 and $13 arms and the trial; drop the setup fee.
3. Define the buyer eligibility rule (5-25 seats, agency) before counting results.
4. Review at 8 weeks against the success and failure signals above.
