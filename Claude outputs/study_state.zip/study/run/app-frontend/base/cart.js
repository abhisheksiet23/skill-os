// Cart summary component. Implement cartHtml(items) and export it (CommonJS).
// items: array of {id: string, name: string, priceCents: int, qty: int}
function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function money(cents) {
  const n = Math.round(Number(cents) || 0);
  const sign = n < 0 ? "-" : "";
  const a = Math.abs(n);
  return sign + "$" + Math.floor(a / 100) + "." + String(a % 100).padStart(2, "0");
}

function cartHtml(items) {
  if (!Array.isArray(items) || items.length === 0) {
    return '<p class="cart-empty">Your cart is empty</p>';
  }
  let count = 0;
  let total = 0;
  const lis = items.map((it, i) => {
    const qty = Number(it.qty) || 0;
    count += qty;
    total += (Number(it.priceCents) || 0) * qty;
    const name = esc(it.name);
    const inputId = "cart-qty-" + i;
    return '<li data-id="' + esc(it.id) + '">' +
      '<span class="cart-name">' + name + '</span> ' +
      '<span class="cart-price">' + money(it.priceCents) + '</span> ' +
      '<label for="' + inputId + '">Quantity for ' + name + '</label> ' +
      '<input type="number" min="1" id="' + inputId + '" value="' + esc(qty) + '"> ' +
      '<button type="button" aria-label="Remove ' + name + ' from cart">Remove</button>' +
      '</li>';
  });
  const summary = '<div role="status" aria-live="polite">' + count + (count === 1 ? " item" : " items") +
    ' &mdash; Total: ' + money(total) + '</div>';
  return '<ul>' + lis.join("") + '</ul>' + summary;
}
module.exports = { cartHtml };
