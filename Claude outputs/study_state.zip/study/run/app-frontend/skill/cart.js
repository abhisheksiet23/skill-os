// Cart summary component. Implement cartHtml(items) and export it (CommonJS).
// items: array of {id: string, name: string, priceCents: int, qty: int}

// Product names are user-supplied, so every dynamic text or attribute value
// goes through this. Quotes are escaped because names are also used inside
// double-quoted attributes (aria-label, data-id).
function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Integer cents -> "$X.XX". Integer math only, to avoid floating-point drift.
function formatCents(cents) {
  const sign = cents < 0 ? "-" : "";
  const absolute = Math.abs(cents);
  const dollars = Math.floor(absolute / 100);
  const remainder = String(absolute % 100).padStart(2, "0");

  return `${sign}$${dollars}.${remainder}`;
}

function itemHtml(item) {
  const name = escapeHtml(item.name);
  const id = escapeHtml(item.id);
  const price = formatCents(item.priceCents);

  // No inline handlers: the host page attaches events (e.g. by delegation,
  // using data-id on the Remove button).
  return `
    <li>
      <span class="cart-item-name">${name}</span>
      <span class="cart-item-price">${price}</span>
      <input
        type="number"
        min="1"
        value="${item.qty}"
        aria-label="Quantity for ${name}"
      >
      <button
        type="button"
        data-id="${id}"
        aria-label="Remove ${name} from cart"
      >Remove</button>
    </li>`;
}

function summaryHtml(items) {
  let itemCount = 0;
  let totalCents = 0;

  for (const item of items) {
    itemCount += item.qty;
    totalCents += item.priceCents * item.qty;
  }

  const noun = itemCount === 1 ? "item" : "items";

  return `
  <div role="status" aria-live="polite">
    <span class="cart-count">${itemCount} ${noun}</span>
    <span class="cart-total">Total: ${formatCents(totalCents)}</span>
  </div>`;
}

function cartHtml(items) {
  if (items.length === 0) {
    return "<p>Your cart is empty</p>";
  }

  const listItems = items.map(itemHtml).join("");

  return `<div class="cart">
  <ul>${listItems}
  </ul>${summaryHtml(items)}
</div>`;
}

module.exports = { cartHtml };
