# BrightLoop: skeptical assessment of the $500k at $5M thesis

**Pending decision:** whether to invest $500k (10% if $5M is post-money; about 11% if pre-money). Exposure is the full $500k. The investor controls the amount, structure and timing.

## Verdict

**Do not invest on this case as written. Fund a bounded test instead, or pass.** The deciding reason is that there is no evidence anyone outside the founder's circle will pay for this. All 10 paying clinics are relatives or former colleagues, so the traction shows personal goodwill and nothing about demand. A $5M valuation sits on about $11.9k of annualized revenue (10 x $99 x 12), roughly 420x. The market, growth, CAC and competition claims each fail on their own arithmetic or evidence, so none of them can carry the case.

The idea itself is not refuted. Clinics lose revenue to no-shows and reminders are a real, understood product category. The case is unproven, and in places it is overstated.

## Strongest version of the thesis

Dental no-shows are costly, and a small clinic can justify $99/month if reminders recover even one or two appointments. Ten clinics pay real money, and none has churned in up to five months. A narrow product may beat bundled reminder modules on simplicity or price for small independent clinics, whose practice-management software is dated or whose reminder module is weak. The founder is shipping and has a distribution contact base. If a stranger segment pays at the same rate, this is a viable small SaaS business.

## Strongest countercase

Reminders are a feature, not a product. Practice-management systems commonly include them, and clinics already running those systems get reminders at no extra cost. The ten payers could be paying out of loyalty, and "50 love us" may mean 40 are on a free tier. The founder has not tested whether anyone else will pay or churn, so the demand curve beyond the founder's circle is unknown. The best defense is that a small-clinic niche without good built-in reminders may exist. That is a hypothesis nobody has checked.

## Claims table

| Claim | Evidence or counterevidence | Decision consequence | Resolving check |
|---|---|---|---|
| **Traction:** "50 love us; 10 pay" | All 10 payers are relatives or ex-colleagues. "Love" is sentiment, not payment. 40 of 50 do not pay. Fault: demonstrated, because the payer list is stated in the case. | No demand evidence from the target market. This is the decisive gap. | Ask 15-20 clinics with no tie to the founder to pay the same $99. Track conversion and 60-day retention. |
| **Market:** "$237M, need 5%" | The arithmetic is right (200,000 x $99 x 12 = $237.6M), but it is a top-down count of every clinic worldwide, not a reachable market. It ignores clinics on bundled software, language, regulation, and non-paying small practices. 5% means 10,000 clinics, more than the 8,000 target and a share no one has reason to expect. | The number gives no support for the valuation or the opportunity size. | Size the reachable segment: clinics in one country, lacking adequate built-in reminders, with a decision-maker the founder can reach. |
| **Growth:** 15% monthly for 36 months to 8,000 clinics | 1.15^36 is about 153. From 10 paying clinics that gives roughly 1,530, not 8,000. 8,000 only works from about 52 clinics, which means counting the 40 non-paying "lovers" as customers. 15% monthly for 3 years is also rare, and no channel is shown that could sustain it. Fault: demonstrated arithmetic error plus an unsupported rate. | The plan mixes users with payers. Treat the 8,000 figure as unsupported. | Rebuild the forecast from paying stranger customers and an observed channel conversion rate. |
| **CAC $40** | $400 ad / 10 clinics. But the 10 are relatives and colleagues, so the ad likely did not acquire them. Founder time and salaries are excluded. Fault: demonstrated definitional error. | True CAC is unknown and probably far higher. At $99/month, gross margin and a payback under 12 months are untested. | Run a paid or outbound campaign to strangers. Log all hours at a market rate and compute fully loaded CAC and payback. |
| **No competition** | The founder did not search. Practice-management software commonly includes reminders, which is the main competitor and substitute. "Nobody does reminders specifically for dentists" is an absence of search, not of competitors. Unsupported, and likely wrong. | Differentiation is untested. Pricing power may be low if reminders come free elsewhere. | One day of competitor and substitute mapping, plus asking prospects what they use today and what they would give up to switch. |
| **Zero churn** | The oldest customer is 5 months old, and all customers are friendly. That is a tiny, biased sample with a short window. Unknown rather than disproven. | Retention cannot support lifetime value or the growth plan. | Observe at least 6-12 months of stranger cohorts. For the investment decision, 60-90 days of stranger retention is a usable early signal. |
| **Ask: $500k at $5M** | Implied about 420x annualized revenue. The case offers no founder-independent traction to justify a premium. | Price is unsupported by the evidence. Valuation can be negotiated, and the evidence cannot yet be. | See the reversal conditions below. |

## What is demonstrated, unknown, and manageable

- **Demonstrated faults:** the growth arithmetic does not reach 8,000 from 10 payers. CAC mixes a relationship channel with an ad cost and omits labor. The traction is entirely from the founder's network.
- **Unknowns:** stranger willingness to pay, true CAC, retention beyond 5 months, and whether bundled software already satisfies the need.
- **Manageable risks:** a founder with no market search can fix that quickly. A small starting base is normal for a seed company, so low revenue alone is not disqualifying. The problem is the valuation set against it and the lack of external proof.

## Smallest decisive test

Run a 6-8 week test with strangers (no relatives or former colleagues): about 100 targeted outreach contacts or ads to one clinic segment, the same $99 offer, and payment collected rather than a pledge.

**Predefine the criteria before running it:**
- At least 8-10 strangers pay, a conversion that supports a channel.
- Fully loaded CAC is below about 6 months of gross margin per clinic (roughly $60-70 contribution at $99 and a plausible 65-70% margin, so a CAC below about $400).
- At least 80% of those payers remain after 60 days.
- Interviews show the clinics were not already getting reminders from their existing software.

These thresholds are proposals the investor should adjust. They must be fixed before the test starts and not moved after an unfavorable result.

## What would reverse the verdict

- **Pass the test above:** reverses the verdict to "invest in a small, staged amount". Strangers paying at the same rate would show the product is a business and not a favor. It supports a seed round in this narrow segment, not the 8,000-clinic plan or the $237M market.
- **Pass the test and accept a lower valuation or a convertible note with a cap:** a $500k round becomes defensible. The investor can reduce exposure by tranching, for example $100-150k now and the remainder on the test results.
- **Fail on conversion or retention, or find reminders already bundled:** pass. Further analysis would not change that.
- **Competitor search shows strong bundled offerings but strangers still pay:** still worth funding, but the case must be rewritten around why they pay and what the real replacement is.

## Owner and next steps

The investor (or investment committee) owns the invest, pass or stage decision. The founder owns running the test and rebuilding the forecast on paying customers. Before the next meeting, ask the founder to (1) list each of the 50 clinics by payer status and relationship, (2) show the ad spend and who it actually reached, and (3) provide the competitor and substitute map. If the economics of a specific channel become the open question, a focused unit-economics review would help, and market-research expertise could size the reachable segment. These are recommendations only.

## Limits

This review uses only the founder draft in `case.md`. I did no outside research and have no data on the clinics, the ad campaign, bundled-software coverage or the investor's return targets. The numeric test thresholds are illustrative and should be set by the investor.
