# BrightLoop: Skeptical Assessment of the Investment Thesis

**Ask:** $500k at $5M valuation (10% equity). **Recommendation: Do not invest on this thesis. Pass for now, or offer a small milestone-based tranche (see "What would change my mind").** Every headline claim in the draft is either unsupported or contradicted by its own numbers. That does not prove the business is bad. It means there is no evidence yet that it is good.

## 1. Claim-by-claim verdict

| Claim | Verdict | Why |
|---|---|---|
| Market is $237M/yr | Arithmetic right, concept wrong | 200,000 x $99 x 12 = $237.6M. That is a top-down ceiling assuming every clinic on earth buys at US pricing. It is not a market. |
| "We only need 5%" | Not a plan | 5% = 10,000 clinics, more than the founder's own 8,000 target. "Only 5%" means beating established competitors in dozens of countries, languages and regulatory regimes. |
| "50 clinics love us; 10 paying" | Weak evidence | All 10 payers are relatives or ex-colleagues. That is a favor, not market demand. 40 of 50 pay nothing, so "love" is unmeasured. |
| 15% MoM for 36 months to 8,000 clinics | Mathematically inconsistent | 1.15^36 = 153x. From 10 paying clinics that gives about 1,530, not 8,000. 8,000 only works from about 52 starting clinics, so the founder is counting the 40 free users as customers. Even then, 15% sustained for three years is top-percentile performance that very few companies hold past year one, and this one has no non-relative sales yet. |
| CAC = $40 | Invalid | See section 2. |
| No competition | False or unresearched | Founder admits no search was done. Practice-management software (Dentrix, Eaglesoft, Open Dental and similar) commonly bundles reminders, and general tools (Twilio-based apps, Weave, Solutionreach, NexHealth, Mailchimp, SMS plugins) exist. Competitors are not "none"; the real competitor is "the reminder feature I already pay for." I have not verified specific vendors here; the founder must. |
| Zero churn | Meaningless | Oldest customer is 5 months. Customers are friendly relatives with a social cost to cancelling. SMB SaaS churn is commonly several percent a month; no cohort has been tested. |
| $5M valuation | Unjustified | Current ARR is 10 x $99 x 12 = **$11,880**. $5M is about 420x ARR. The only support is the projected 8,000 clinics (about $9.5M ARR in month 36), which rests on the broken growth math above. |

## 2. CAC is not $40
- $400 of Facebook ad for "10 clinics" assumes the ad produced them. The 10 paying clinics are relatives and colleagues, who were not acquired by ads. The real paid-channel CAC is **unknown**, and could be infinite if ads produced none.
- Founder time, the main cost of early B2B sales (demos, onboarding, calls to clinic owners), is excluded. Dental offices are reached through calls, referrals and conferences, not mostly ads. Even at a modest $50/hr and 5 hours per sale, that adds $250 per clinic, before salaries, tooling, support and onboarding.
- A fully loaded CAC of several hundred to over $1,000 is plausible. Against $99/month gross revenue (less SMS costs, payment fees, support), payback could be 6 to 15+ months, which changes the funding need and the growth math entirely.

## 3. Unit economics, quickly
- Revenue per clinic: $1,188/yr. Gross margin is unstated; SMS/voice cost per message was not mentioned and is a real COGS line.
- Illustrative: if monthly churn is 3%, average lifetime is about 33 months, LTV about $3,300 at 100% margin. That is healthy only if CAC is below roughly $1,000 and churn is truly that low. None of the inputs are measured.
- No-show reduction is the real value claim ("reminders save the clinic money"). There is no data on show-rate improvement, which is the proof a dentist would pay for.

## 4. What the $500k buys
No burn, runway, headcount or use-of-funds is given. At 10% equity for $500k, investors need roughly a 10x+ outcome to be interesting at venture return levels. That implies a large exit, but the market sizing offers no credible path (the realistic reachable segment is unproven, and a feature-sized product sold at $99/month is exposed to bundling by incumbents).

## 5. Biggest risks, ranked
1. **Commoditization / bundling:** reminders are a feature of existing practice-management systems. Wedge product risk is the central thesis risk.
2. **Unproven demand:** zero arm's-length customers.
3. **Unproven acquisition channel:** no repeatable, measured way to reach dental clinics at a known cost.
4. **Founder-only sales dependence** and unmeasured time cost.
5. **Integration burden:** to be useful, a reminder tool must sync with the clinic's scheduling system. Integration cost and partner dependence (incumbents control APIs) are not addressed.
6. **Regulatory/privacy:** patient contact data (HIPAA in the US, GDPR in the EU, SMS consent laws) is unmentioned for a global pitch.
7. **Credibility:** the draft contains several errors and unresearched assertions. That reflects on diligence habits, not just this document.

## 6. What the founder got right
- The pain (no-shows) is real and quantifiable in dental practice.
- The founder has 5 months of operating product and 10 paying users, which is more than many pitches.
- Narrow vertical focus can win against horizontal tools if it is deeply integrated.

## 7. What would change my mind (cheap, falsifiable tests, 60-90 days)
1. **Arm's-length sales:** sign at least 15-20 paying clinics with no personal relationship, in one country and one or two named practice-management systems. Record every touch and hour.
2. **Honest CAC:** log all founder time and spend per channel. Report fully loaded CAC and payback.
3. **Outcome proof:** measure no-show rate before vs. after for at least 10 clinics.
4. **Competitor teardown:** map the reminder features of the top 5 practice-management systems in the target country, plus the leading standalone tools. State what BrightLoop does that they cannot or will not, and what share of clinics already have free reminders.
5. **Churn and willingness to pay:** convert some of the 40 free clinics to paid at $99; track 3-month retention of non-relatives. Test $99 vs. a higher price.
6. **Rebuild the model:** bottom-up (reachable clinics in one region x realistic conversion x measured sales capacity), with 3 scenarios, burn and runway.

## 8. Decision and terms
- **Pass at $5M on current evidence.** A fair pre-seed value for $12k ARR with no independent customers is far lower; I would not anchor on $5M.
- If interested anyway: stage the money. For example, $100-150k now (or a SAFE with a cap well below $5M) and the remainder released upon the milestones in section 7 (e.g., 20 independent paying clinics, measured CAC payback under 12 months, monthly churn under 4%).
- Ask the founder to answer first: Which clinics came from the ad? What do incumbents' reminder features cost the clinic today? What is the first-year plan for the $500k?

## Assumptions and limits
- Based solely on the founder's draft; no market data, web research or customer interviews were used. Competitor names are from general knowledge and unverified.
- Figures marked illustrative (churn, hourly rate, hours per sale) are assumptions to show sensitivity, not findings.
