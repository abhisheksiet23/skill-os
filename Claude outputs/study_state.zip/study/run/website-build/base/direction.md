# Approved direction — Northgate Bookkeeping (one page)
Positioning: calm, plain-spoken bookkeeping for small trades and retail. Palette: deep green #1f4d3a, off-white #f7f5ef, accent amber #c98a1b. Font stack: system fonts only.
Sections in order: header with phone "(555) 010-2244" and a "Book a free 30-minute call" button; hero; services (monthly bookkeeping, payroll, year-end tax pack); how it works (free call, 2-week onboarding, monthly reports by the 10th); about Helen Park (CPA, 11 years in practice, firm started 2019); testimonial (Dave R., Reyes Plumbing: "Helen sorted two years of mess in a month."); contact form; footer.
Contact form fields: name (required), email (required), phone (optional), message (optional), and a checkbox "I'd like a call back". Form posts to https://forms.example.com/northgate (placeholder endpoint; do not build a backend).
Claims allowed: only those stated above. Do NOT add awards, ratings, client counts, turnaround claims, prices or guarantees.
Constraints: single file site/index.html with inline CSS (no external requests), mobile-first, accessible (labels, contrast, focus visible, alt text for any images), semantic landmarks.
