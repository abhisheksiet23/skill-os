# Northgate Bookkeeping — facts from owner
Services: monthly bookkeeping, payroll processing, year-end tax pack prep for small businesses (1-20 staff), Xero and QuickBooks Online.
Team: owner Helen Park (CPA designation, 11 years in practice, started firm 2019) plus 2 staff.
Clients: about 45 active clients; mostly trades and small retail in one metro area.
Pricing: from $350/month for bookkeeping; not published; custom quotes.
Process: free 30-minute call, onboarding in 2 weeks, monthly reports by the 10th.
Testimonial 1 (permission given, name used): "Helen sorted two years of mess in a month." - Dave R., Reyes Plumbing.
Testimonial 2 (anonymous, from an email, no permission to publish yet).
Claims the owner wants: "Fastest turnaround in town" (no evidence), "Trusted by 45 businesses", "No hidden fees".
Current site: a one-page WordPress template with a contact form emailing the owner's personal Gmail; no analytics.
Goal: more leads from local small businesses; owner will take calls herself.
Not provided: certifications beyond CPA, service area boundaries, client industries list, turnaround data, fee terms.
