# DeskSwap: is it validated, and what next?

## Verdict
**Not validated.** You have friendly interest, not behavioral evidence of a problem, demand, or willingness to pay. That is a normal starting point, not a failure. Nothing here says the idea is bad; it says the evidence so far can't distinguish good from bad.

## Why the current evidence doesn't count
| Your evidence | Why it's weak | What it actually shows |
|---|---|---|
| 40 waitlist signups, mostly friends/ex-colleagues | Warm network, no cost to sign up, no source tracking; friends are polite and biased toward you | Your network is supportive. Says nothing about strangers. |
| "They all said they love the idea" | Compliments are opinions about an idea, not behavior; no one gave time, data, money or a commitment | Zero demand signal |
| "Sure 12 offices would pay $50/mo" ($600/mo) | This is a forecast, not evidence. Two nods at a party (n=2, casual, no ask made) | Politeness; the "12" and "$50" have no source |
| Landing page draft, no analytics | Cannot measure anything yet | Nothing yet |
| Pilot at friend's former employer | Friendly HR director = biased test, and a "yes" proves little | Possible, but must be designed carefully |

Also note a buyer/user split: employees swap desks, but the office manager/HR/facilities pays. The waitlist is mostly the wrong person (users, not buyers).

## Unresolved questions (in order of risk)
1. **Problem:** Do offices with assigned desks actually have a recurring pain (people wanting to sit near a team, hybrid days, etc.), or is it a mild nice-to-have? Why not hot-desking, a spreadsheet, Slack, or facilities software they already have?
2. **Buyer:** Who owns the budget (office manager, facilities, HR, IT)? Is $50/month per office a plausible, approvable amount, or too trivial to prioritize, or too low to sustain you?
3. **Adoption:** Will employees use it without being forced? Swapping needs two willing people, so there's a two-sided/critical-mass issue inside each office.
4. **Willingness to pay:** untested entirely.
5. **Operational blockers:** seating policies, security/badging, IT approvals, HR data (not yet known).

## Plan: ~3 weeks, ≤$300, evenings only
**Constraint:** I have not contacted anyone or spent money; everything below is for you to do. Contacting people is your call.

### Week 1: Fix the evidence base, talk to strangers
- Write down, before testing, what would **kill** or **support** the idea (thresholds below).
- Add basic analytics to the landing page (free tools; or just unique tracking links per channel). Rewrite it to speak to the **buyer** (office manager) with one clear call to action.
- Reclassify your 40 signups: friend / ex-colleague / stranger; user vs. buyer. Only strangers and buyers count toward evidence.
- Do **8-10 problem interviews with office managers/facilities/HR people who are not friends** (cold LinkedIn messages, local coworking/office-manager communities, friends-of-friends intros but not friends themselves). Ask about past behavior, not the idea: "Tell me about the last time someone asked to change desks. What happened? What do you use today? What did it cost you?" Do not pitch. Do not ask "would you use this?"
- Cost: $0.

### Week 2: Test demand with a costly signal
- Offer interviewees (and a small cold outreach list, ~40-60 office managers) a **concrete next step that costs them something**: a 20-minute demo-of-a-mockup call, sharing their current seating process or floor plan, or a signed non-binding pilot/letter of intent, or a paid pre-order/deposit at the intended price if feasible.
- Optionally $100-150 on a targeted ad or newsletter placement to the buyer persona, driving to the landing page with a "request pilot" form (not just "join waitlist"). Track conversion by source.
- Test price by asking in interviews: "What do you pay now for similar tools? At what point is this too cheap to be credible, or too expensive to approve without a committee?" Try two or three price points (e.g., $50 per office vs. per-seat pricing), and note who must approve.
- Cost: up to ~$150.

### Week 3: A cheap, honest pilot
- Run a **concierge pilot** (no heavy build): a shared form/spreadsheet + manual matching for one team at one office. Prefer a pilot where the champion isn't a friend; if you must use your former employer, treat it as a **weak** test, have the HR director commit in writing to specific usage targets in advance, and judge only on usage by employees you haven't personally recruited.
- Measure behavior: how many swap requests are made, how many are matched, repeat use in week 2, and whether the manager says the pain reduced.
- Cost: ~$0-50.

## Decision rules (set now, adjust if you disagree)
These thresholds are suggestions, not industry benchmarks; choose your own, but write them down before you look at results.

- **Pursue / keep building** if most of: at least 5 of ~10 non-friend buyers describe a recurring, costly desk-change problem unprompted and are currently using workarounds; at least 3 take a costly next step (pilot commitment, LOI, deposit); at least a few say $50/month is acceptable without needing a long approval; pilot shows repeat employee use without prodding.
- **Pivot** if the pain is real but different (e.g., hybrid desk booking, room booking), or buyers want a bigger product at a higher price.
- **Park/stop** if buyers shrug, say existing tools or a spreadsheet are fine, give only polite interest and no commitment, or the price they would approve is too low to ever be worthwhile ($600/mo at your hoped 12 offices is a small business; check whether that number is even your goal).

## What not to do
- Don't build more product before steps above.
- Don't count the waitlist, friends' enthusiasm, or "nods" as validation.
- Don't lead with the pitch; don't offer discounts that mask price sensitivity.
- Don't use the friendly pilot as proof of market demand.

## Limits of this assessment
Based only on the brief. I have no market data, haven't researched competitors or contacted anyone, and didn't verify any claims. The numbers above (sample sizes, thresholds, ad budget split) are working suggestions, not evidence-based benchmarks. A 10-interview sample can disprove or sharpen the idea but will not prove market size.
