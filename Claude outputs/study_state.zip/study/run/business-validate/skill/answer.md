# DeskSwap: validation assessment

## Learning decision: Not validated. Test before building more, and reshape the first test toward the buyer.

Nothing in hand is behavioral evidence of demand from the people who would pay. The next step is one cheap, falsifiable test aimed at office managers, with the pilot used only for learning about usage. This is a plan. I have contacted no one and spent nothing, and nothing below is authorized until you decide to run it.

## What the current evidence is worth

| Claim | What it actually shows | Limitation |
| --- | --- | --- |
| 40 waitlist signups, "they all said they love it" | Friendly interest from your network | Friends and former colleagues are biased and are mostly users, not buyers. No cost or commitment was involved, and the signup source and denominator are unknown. Stated enthusiasm is not behavior. |
| "12 offices would pay $50/month" | A hope. The number 12 is not derived from any observation | Two nods at a party are politeness. Neither was asked for a commitment, and neither is a demonstrated buyer. Nobody has been asked about price. |
| Landing page draft, no analytics | No exposure data yet | Without measurement, any later result is uninterpretable. |
| Pilot at the HR director friend's employer | A possible source of usage observation | Founder friendship, goodwill and manual help will inflate results. It tests user behavior inside one firm, not whether a buyer pays. |

Open risks: desirability for the buyer (is swapping a real, painful problem?), the buyer/user split (employees want swaps; office managers or HR pay), feasibility (assigned-desk offices are a subset; many have hot-desking already, which is the current workaround), economics ($50/month needs a lot of offices), and distribution (how you reach office managers).

## Decision this serves

Whether to keep building DeskSwap for office managers at all, and at roughly what price. The consequential assumption is that an office manager with assigned desks has a recurring problem they will pay to solve, given their current workaround (spreadsheets, a chat message, hot-desking, ignoring it).

## Recommended test (one decisive test, about 3 weeks, within $300)

- **Hypothesis:** Office managers (or HR/facilities leads) at companies with assigned desks and 20+ desk-holders who currently handle desk swaps or desk shortages by hand will take a costly commitment, such as a paid pilot at a stated price or a signed letter of intent naming a start date, after seeing a clear description of DeskSwap at about $50/month.
- **Eligible audience and exposure:** Offices with assigned desks and some hybrid attendance. Count separately: people contacted, those who are eligible (screen question: how do desk swaps or unused desks get handled today, and how often?), those who saw the offer, and those who were asked for a commitment. Use warm-but-not-friend referrals and direct outreach; exclude friends.
- **Method:** (1) Ask 10 to 15 eligible managers about the last time desk swapping or unused desks was a problem and what they did, asking for the actual recent event. (2) Show a one-page offer and a landing page with basic analytics. (3) Ask for the commitment: paid pilot or LOI, with a dated start. Optionally, a concierge version (a shared sheet you run by hand) for 1 to 2 willing offices.
- **Signal and threshold:** Set before starting, from your decision. Suggested: at least 3 of roughly 12 eligible buyers who understood the offer make a real commitment (payment or signed LOI). Treat 0 commitments from 10 or more qualified, comprehending buyers as adverse evidence for this offer and segment (small sample). Anything in between, or fewer than about 8 eligible buyers reached, is inconclusive. This is a judgment threshold, not a universal quota, and you should adjust it to what 12 offices at $50 actually means for your goals.
- **Interpreting failure:** Use the funnel. Few eligible people reached means an access failure and demand is unknown. Reached but unable to explain the outcome or price means a comprehension failure; fix the wording and repeat the same ask. Understood but they prefer their workaround means weak relative value or the wrong trigger; ask why, and do not just buy more traffic. Claimed intent without logged commitments means a measurement failure and the result is inconclusive.
- **Pilot at the friend's employer:** Run it as a usage observation only, if the HR director agrees: do people actually swap, how often, and with what manual help from you? Do not count it as evidence that buyers will pay. Discount its results for friendship and heavy hand-holding.
- **Time and cost bound:** About 3 weeks of evenings. Budget well under $300: analytics (free or low-cost), a small amount for a domain or form tool, no paid ads until you know eligible buyers are reachable. Stop at the end of week 3 and decide.
- **Next decision:** Stop or park if no commitments from qualified buyers; reshape (different segment, trigger or price) if buyers understood and declined; continue to a paid pilot if the threshold is met, noting repeatability is still unproven until a second natural use cycle.

## What to do first (this week)

1. Add analytics to the landing page and rewrite it around the office manager's problem and outcome, not the swap feature.
2. Reclassify the 40 signups: how many are managers or buyers in assigned-desk offices? Most likely few. Keep the list, but do not cite it as demand.
3. Write down your thresholds above before any outreach.
4. List 20 to 30 eligible office managers reachable through non-friend routes, then decide whether you authorize contacting them.

## Assumptions and limits

I assumed the facts in the brief are complete and accurate. No customer, market, or competitor data was gathered. The thresholds are illustrative judgments. If pricing remains uncertain after this test, `business-pricing` fits; if you need to know whether $50 per office works economically, `business-model` fits.
