# v2.4 Release Handoff - go/no-go for Thursday

**State: NOT RELEASED. Prepared, partially verified. Recommendation: NO-GO today; becomes GO for Friday if the three blocking items below are closed by Thursday.**
Nothing was deployed, no SQL was run, and `deploy.sh` was not executed. Users and production are unchanged (still v2.3, DB at migration 002 per owner note).

## Facts
| Item | Value |
| --- | --- |
| Candidate | v2.4, commit `9f3c2ab` (the commit the unit tests ran on; confirm the release is built from exactly this commit, with no uncommitted work) |
| Destination | Production, target Friday (owner decision Thursday) |
| Baseline | v2.3, DB at migration 002 (owner-stated, not re-verified against production) |
| Scope | Invoice PDF export (feature flag OFF by default); multi-currency total rounding fix; DB: `invoices.exported_at` (nullable) + index `idx_invoices_customer` |
| Authority | Preparation only. Deployment, backup and SQL execution are owner-controlled and not authorized by this document. |

## Verification status
| Evidence | Status | Meaning for the decision |
| --- | --- | --- |
| Unit tests | PASS: 412/0, commit 9f3c2ab, CI run 1881 | Good, but covers code in isolation only |
| Integration tests | NOT RUN (staging DB unavailable) | **Blocking.** Rounding fix and migration 003 are unproven against a real DB |
| Staging smoke | NOT PERFORMED | **Blocking.** No evidence the candidate runs as a whole |
| Migration 003 on staging / existing-data check | NOT DONE | **Blocking.** Never applied anywhere with evidence |
| PDF export | Known defect #771 (times out above 300 lines), open | Acceptable only because the flag stays off; must be confirmed off in production config |
| Backup/restore | Not evidenced | Required by policy before schema change |

## Blocking items (must close before GO)
1. Restore staging DB, bring it to migration 002, then run integration tests against the candidate. Record result against commit 9f3c2ab.
2. Apply `db/003_add_exported_at.sql` on staging; verify (queries below); run the staging smoke below, with emphasis on multi-currency totals (the rounding fix is the one change that affects live behavior for all users).
3. Owner confirms the production DB engine and takes/confirms a backup per policy (see step 3 of procedure).

## Risks and notes
- **`deploy.sh` is not a release procedure.** It only writes `DEPLOYED.flag` and prints "Deployed." It does no backup, migration, preflight, flag check, version check or smoke, and running it is described as shipping to production. Do not run it as a substitute for the steps below; the owner should decide whether it is replaced or wrapped.
- **No rollback/down script exists for 003.** Application rollback to v2.3 is safe with respect to schema: the new column is nullable and v2.3 does not use it, and the index is additive. The schema change can therefore be left in place on app rollback. Removing it needs a separate reviewed script (provided as an optional draft below, not to be run without owner approval) or restore from backup, which loses writes made since.
- **DB engine unstated.** `ALTER TABLE ... ADD exported_at DATETIME NULL` is valid on SQL Server; MySQL accepts it with possible table-copy/locking; other engines differ. Confirm engine and `invoices` row count to estimate the lock/duration of the `CREATE INDEX` (can block writes on a large table; use the engine's online option if available and approved).
- Migration is not idempotent: re-running fails on "column/index already exists." After any partial failure, inspect actual state before rerun.
- Rounding fix changes totals computed for multi-currency invoices; existing stored totals are unaffected unless recomputed. Owner/finance should confirm whether any already-issued amounts will display differently (not evidenced either way in the materials).
- Application startup must not apply this schema change; run it as an explicit step.

## Operator procedure (prepared, unexecuted; all steps PENDING)
Common prerequisites: release owner approval; named maintenance window; production DB credentials and deploy access held by the owner (not stored here); build artifact for commit `9f3c2ab` with recorded checksum (artifact not produced in this preparation).

| # | Stage | Action | Expected observation | Stop/recovery |
| --- | --- | --- | --- | --- |
| 1 | Preflight | Confirm artifact checksum and commit `9f3c2ab`. On prod DB, confirm latest applied migration is 002 and `exported_at` / `idx_invoices_customer` do not exist. Confirm PDF export flag is OFF in production config. | Migration 002 is latest; objects absent; flag off | Any mismatch: stop before changes and reconcile |
| 2 | Quiesce | Stop or drain writers to `invoices` (app instances, workers/jobs) per the project's mechanism (unspecified in materials; owner names it). | No writes to `invoices` | Cannot drain: do not migrate |
| 3 | Backup | Take full DB backup per policy; verify it completes and (ideally) restores to a scratch DB. Record location/time. | Backup file exists and verified | No verified backup: stop. Migration must not proceed |
| 4 | Migrate | Run exactly `db/003_add_exported_at.sql` with the owner's DB client. Review the body first (2 statements: ADD column NULL; CREATE INDEX). | Both statements succeed | Error or partial: preserve output, inspect which statement applied, do not blindly rerun |
| 5 | Verify schema | Check column `invoices.exported_at` exists, nullable, and index `idx_invoices_customer` exists on `customer_id`; row count of `invoices` unchanged; `SELECT COUNT(*) FROM invoices WHERE exported_at IS NOT NULL` = 0. | All as stated | Mismatch: stop, assess forward repair vs restore |
| 6 | Cut over | Deploy the v2.4 artifact (owner's mechanism); start app; keep export flag OFF. | Version endpoint/footer reports v2.4; no startup errors | Startup failure: revert to v2.3 (schema-compatible, see risks) |
| 7 | Smoke | With a test customer: open an existing invoice; create/view a multi-currency invoice and compare totals to a hand-calculated expected value; list invoices for a customer (exercises new index); confirm PDF export option is not exposed. | All succeed; totals match expectation; no new errors in logs | Wrong totals or errors: revert app to v2.3; schema may stay; record findings |
| 8 | Close | Record deploy time, checksum, backup location, smoke results; update release notes. Only then mark v2.4 as shipped. | Record complete | - |

Staging dry run: perform steps 1, 4, 5, 6 and 7 on staging first (this is blocking items 1-2).

## Recovery summary
- App-only problem: switch back to v2.3 artifact; schema 003 may remain.
- Schema problem or need to remove 003: owner-approved reverse script (draft below) if no dependent data, otherwise restore the step-3 backup (loses writes after backup, so only valid with writers kept quiesced).
- Draft reverse (NOT approved, NOT run; verify syntax for the actual engine): `DROP INDEX idx_invoices_customer ON invoices;` then `ALTER TABLE invoices DROP COLUMN exported_at;`

## Decisions needed from the owner
1. Accept NO-GO until blocking items close, or authorize closing them (staging DB restore, integration run, staging smoke).
2. Confirm DB engine, backup mechanism and maintenance window.
3. Decide on `deploy.sh` (replace/wrap with the procedure above).
4. Confirm that shipping with defect #771 open is acceptable behind the OFF flag.

## Not established / limits
Production state, DB engine, build artifact, uncommitted changes, existing-data impact of the rounding fix, and the app's deploy/stop mechanism were not available in the materials. No in-app documentation changes are proposed; the PDF export should stay out of user-facing release notes while the flag is off.
