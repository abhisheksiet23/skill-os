# v2.4 Release Handoff - Go/No-Go Package (for Thursday decision)

Status as of this package: **NOT READY - recommendation: NO-GO today; becomes GO if the "Required before GO" items below are closed by Thursday.**
Nothing has been deployed. `deploy.sh` was not run (it ships straight to PRODUCTION and has no checks). Deployment needs your explicit go.

## 1. What is in v2.4 (CHANGELOG)
| Change | Risk | Notes |
|---|---|---|
| Invoice PDF export | Low in production | Feature flag OFF by default. Known issue #771: times out on invoices > 300 lines. Flag must stay off. |
| Fix rounding on multi-currency totals | **Medium-High** | Changes money amounts on live paths. Only unit-tested; never run against a real DB or on staging. |
| DB migration 003: `invoices.exported_at` (nullable) + index `idx_invoices_customer` | **Medium** | Schema change, so backup policy applies. Index build may lock/slow `invoices` on a large table (table size unknown). |

## 2. Verification status
| Check | Result | Evidence |
|---|---|---|
| Unit tests | PASS - 412/0 failed | commit 9f3c2ab, CI run 1881 |
| Integration tests | **NOT RUN** (staging DB unavailable) | reports/test-report.md |
| Staging smoke test | **NOT PERFORMED** | reports/test-report.md |
| Migration 003 applied/tested on any DB | **NOT EVIDENCED** | No log provided |
| Migration rollback tested | **NOT AVAILABLE** | No down/rollback script in `db/` |
| Production backup | **NOT EVIDENCED** | Required by policy before schema change |
| Production baseline at migration 002 | **NOT VERIFIED** | Taken from owner note (v2.3 was at 002); should be confirmed on prod before applying 003 |
| Deployed candidate verification | N/A - not deployed | |

Not claimed: the unit pass says nothing about the migration or the rounding fix against real data.

## 3. Required before GO (blockers)
1. Restore staging DB; run integration tests on commit 9f3c2ab; attach results. Pay particular attention to multi-currency totals (rounding fix).
2. Apply migration 003 to staging (from 002); record success and duration of the index build; confirm app starts and invoices read/write normally.
3. Staging smoke: create/view invoices in several currencies, confirm totals; confirm PDF export flag is OFF and the export path is unreachable.
4. Production backup taken and restore-verified (policy: before any schema change). Record backup id/time.
5. Confirm production is currently at migration 002.
6. Rollback plan agreed (see section 5), because no rollback script exists.
7. Owner confirms #771 is acceptable with flag off, and that the client is not expecting PDF export to work Friday.

## 4. Proposed execution plan (only after GO and explicit authorization)
1. Announce window; choose low-traffic time (Friday, time TBD by owner).
2. Take production backup; verify it (blocker 4).
3. Confirm prod schema = 002.
4. Apply `db/003_add_exported_at.sql` (nullable column plus index; app code tolerates the column being absent/null is NOT confirmed - deploy order to be confirmed by dev: migrate first is the safe order since the column is nullable and additive).
5. Deploy v2.4 build (commit 9f3c2ab) via the approved deploy process. Note `deploy.sh` here only writes a flag file and does not itself perform checks or backup - do not treat it as a verified procedure.
6. Post-deploy verification: app health, create an invoice in a multi-currency case and check totals, confirm PDF flag off, check error logs and DB for lock/slow queries, confirm `idx_invoices_customer` exists.
7. Reconcile: update release notes/known issues (#771), record migration level 003 as production state.

## 5. Rollback
- Application: redeploy v2.3 build. Safe against schema 003 because the column is nullable and additive (to be confirmed in staging).
- Database: no down script provided. Draft (needs dev review and staging test): `DROP INDEX idx_invoices_customer ON invoices; ALTER TABLE invoices DROP COLUMN exported_at;` (syntax depends on DB engine; the dialect is not stated). Leaving the schema at 003 with v2.3 code is the lower-risk fallback; full restore from backup is last resort and loses data written after the backup.
- Rounding fix: if wrong totals are detected, rollback app, then identify and correct invoices created during the window.

## 6. Open risks / unknowns
- `invoices` table size and DB engine unknown; index build time/locking not assessed.
- Rounding fix changes historical vs new totals behavior; no evidence of how existing invoices are affected.
- Timeline: Thursday decision leaves one day for blockers 1-5; if staging DB cannot be restored by Thursday, recommend moving the release rather than shipping untested.

## 7. Decision requested (Thursday)
- GO: all section 3 items evidenced; owner authorizes production deploy.
- NO-GO / defer: any of items 1-5 not closed.
- Interim to tell the client: Friday is at risk pending staging verification.
