# ShopRight "Return an item" prototype - notes

Open `prototype.html` in a browser (single file, no network). A dark bar at the top holds prototype controls: set delivery age (12 / 30 / 34 days) and make the next submit fail. Sample login: order SR-48213, sam.rivera@example.com (a "fill sample order" link is provided).

## What it demonstrates
- Main journey: order lookup -> choose items and reasons -> refund method -> review -> confirmation with label, drop-off list and timeline.
- Hardest decision: refund method. Both options show the exact amount (net of label fee; store credit shows the +10% bonus), timing, and irreversibility, with a running refund summary (sticky bottom bar on mobile, side panel on wide screens).
- States: field validation, order not found, lookup failure with retry, loading (lookup and submit), outside 30-day window, no item selected, missing reason, used item blocked (allowed if faulty), no refund method chosen, submit failure with retry and choices preserved, success.
- Checked in headless Chrome at 390px and 1200px (happy path, submit failure, expired state); no console errors. Keyboard: native controls, visible focus, focus returns to the changed control after re-render. Not tested at tablet width, with a screen reader, or by users.

## Assumptions (not in the brief - confirm)
- The $4.50 label fee is charged once per return, and waived only when every returned item is faulty (mixed returns pay it).
- The 10% store credit bonus is calculated on the refund after the label fee.
- A used item is accepted only if the reason is "faulty".
- Window is 30 days inclusive of day 30; the 14-day drop-off deadline, "Visa ending 4417" and the reason list are invented.
- Choosing a method is changeable until confirm.

## Does not demonstrate
- Any real lookup, payment, label generation, email or carrier integration; all data is simulated and nothing persists on reload.
- Real drop-off locations (placeholders), partial quantities, multi-package returns, guest vs signed-in differences, support contact flow, localization.
- Photo upload for faulty items, which production may need.
