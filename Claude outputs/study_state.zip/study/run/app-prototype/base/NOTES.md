# Return flow prototype - notes

**File:** `prototype.html` (single file, inline CSS/JS, no network). Mobile-first 390px frame plus a side "inspector" to jump between states (hidden on narrow screens).

## Demonstrates
- Main journey: order lookup (order no. + email) -> choose items + reason per item + unused confirmation -> refund vs store credit (+10%) -> review with itemised totals -> confirmation with label, steps, drop-off placeholders.
- Policy logic: 30-day window (days left shown), $4.50 label fee deducted, fee waived when returned items are faulty, store-credit bonus, 5-7 business day refund copy.
- States: field validation, loading, order not found, outside window (41 days), already returned, no item selected, missing reason/unused confirmation, submit failure with retry.
- Sample data: SR-48213 / ana@example.com (shoes $89.00, socks $24.00, bottle $18.50).

## Does not demonstrate
- Real backend, auth, label generation (barcode is decorative), email, or real carrier locations (placeholders).
- Desktop layout, accessibility audit, localisation, partial/duplicate-return edge cases beyond the two sample orders.

## Assumptions (not in the brief - confirm)
- Fee is waived only if all returned items are faulty; mixed returns pay $4.50.
- Credit bonus = 10% of net (after fee) amount.
- "Return within 14 days of submitting" is invented.
- Faulty items outside the window point to support (illustrative).
- Demo emails/order numbers other than SR-48213 are invented.
