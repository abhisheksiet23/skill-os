# Raw idea (owner)
"Monthly subscription box of regional spices and recipe cards for people living in small apartments. $24/month, free shipping. I think young professionals in big US cities will love it. I can source from two spice suppliers I met at a trade show. I have $5,000 and evenings/weekends. I want to know: should I pursue this?"
Not known: supplier terms, shipping cost per box, existing competitors, customer acquisition channels, demand evidence.
