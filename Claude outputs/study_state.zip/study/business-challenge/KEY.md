Expectations (business-challenge):
E1 Market logic: 200k x $99 x 12 = $237.6M is TAM arithmetic only; "5% of a big market" is not a plan; reachable/serviceable market, language/regulation, clinics already using software not considered.
E2 Traction bias: 10 paying all from founder network; "50 love us" not behavioral evidence; not representative.
E3 Growth: 15% monthly for 36 months compounds ~ 150x; check implied 8,000 clinics vs 10 start is inconsistent with 15%/mo (10*1.15^36 ~ 1,525); flagged either way.
E4 CAC omits founder time/salary, sample of 10 from network; not scalable.
E5 Competition claim unsupported; substitutes (practice management software, SMS tools) not considered.
E6 Zero churn from 5-month-old base is not informative; no cohort.
E7 Valuation/ask has no support; decision-focused: states what evidence would change mind, which assumption matters most; not performative negativity (acknowledges any credible strength).
Traps: rejecting wholesale without specifics; inventing market statistics as facts.
