# BrightLoop — investment thesis (founder draft)
Product: SaaS that automates appointment reminders for dental clinics. Price $99/month.
Market: "There are 200,000 dental clinics worldwide, so even at $99/month the market is $237 million a year, and we only need 5% of it."
Traction: "50 clinics love us; 10 are paying." (all 10 are clinics owned by the founder's relatives or former colleagues)
Growth: "We will grow 15% month over month for 36 months, reaching 8,000 clinics."
CAC: "Our CAC is $40 because our only cost is a Facebook ad of $400 for 10 clinics." (founder's own sales time not counted; no salaries included)
Competition: "None. Nobody does reminders for dentists specifically." (founder did not search; practice-management software commonly includes reminders)
Churn: "Zero churn so far" (oldest customer is 5 months old)
Ask: $500k at $5M valuation.
