Challenge this business case. Produce a skeptical assessment (markdown in your working directory) that a decision-maker can act on. Do not ask the user questions.
