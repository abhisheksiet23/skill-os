# Project instructions
- Keep accepted decisions in decisions.md; never delete a superseded decision, mark it superseded.
- checkpoint.md holds current state only (replace, don't append history).
- Local maintenance does not authorize commit, push or deployment.
