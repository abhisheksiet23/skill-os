# Ledgerly (internal invoicing tool)
Small internal tool. Map: AGENTS.md (rules), decisions.md (accepted decisions), checkpoint.md (current state), workstreams/ (one file per stream).
