# Export workstream
2026-10-17: CSV export endpoint done, tests green (owner-reported).
2026-10-27: Postgres migration started on branch pg-migrate (not merged).
