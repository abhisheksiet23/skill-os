# Decisions
D1 (2026-10-03, accepted by owner): Use PostgreSQL, not SQLite, for all environments.
D2 (2026-10-10, accepted by owner): Invoices export to CSV and PDF.
D3 (2026-10-14, provisional assumption): Single currency (USD) until finance confirms.
