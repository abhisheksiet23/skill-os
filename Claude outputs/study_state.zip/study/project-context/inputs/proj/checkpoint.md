# Checkpoint (as of 2026-10-20)
- Database: SQLite file in dev, migration to be decided.
- Export: CSV export implemented; PDF export not started.
- Next: finish invoice list screen.
