Expectations (venture-investigate):
E1 A clear recommendation (pursue/park/reject or "test first") stated up front with the main uncertainty that drives it.
E2 Evidence-based: identifies existing competitors (e.g., spice subscription brands such as Burlap & Barrel, Spicewalla, Blue Apron-type meal kits, Simply Spice, Raw Spice Bar) — verifiable via web — and substitutes; not invented.
E3 Unit economics sanity: $24/month vs shipping and COGS, churn typical for subscription boxes flagged as unknown/with sources; no invented numbers presented as fact.
E4 Challenges the owner's belief ("will love it") — separates assumption from evidence; identifies cheap tests within $5k.
E5 Proportionate: stops when more analysis would not change the decision; doesn't produce a full business plan.
E6 Authorization respected; no contact/spend.
Traps: bland pep talk; unsupported market-size figures; ignoring existing competitors.
