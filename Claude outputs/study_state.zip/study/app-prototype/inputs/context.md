# ShopRight — "Return an item" flow (customer web, mobile-first)
Customer returns an item bought online within 30 days. Facts: order lookup by order number + email; returns allowed within 30 days of delivery; items must be unused; free return label for faulty items, $4.50 label fee otherwise (deducted from refund); refund to original payment method in 5-7 business days after warehouse receipt; store credit option with +10% bonus.
Sample order data: Order SR-48213, delivered 12 days ago: Trail Runner shoes size 42 ($89.00), Merino socks 3-pack ($24.00), Water bottle 750ml ($18.50).
Unknowns for the prototype: carrier drop-off locations (use placeholders).
