from shop import pricing


def run_rule(kind, *args):
    """Dispatch pricing rules by name, e.g. kind='discount' -> calc_discount."""
    fn = getattr(pricing, "calc_" + kind)
    return fn(*args)
