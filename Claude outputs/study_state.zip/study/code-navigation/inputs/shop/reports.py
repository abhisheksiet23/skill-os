from shop.pricing import calc_discount_legacy


def nightly(orders):
    return sum(calc_discount_legacy(o["total"]) for o in orders)
