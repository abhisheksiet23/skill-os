def calc_discount(order, rate):
    """Return discount amount for an order."""
    return round(order["total"] * rate, 2)


def calc_discount_legacy(total):
    # old flat-rate version, still used by the nightly report
    return total * 0.05


def calc_tax(order):
    return round(order["total"] * 0.2, 2)
