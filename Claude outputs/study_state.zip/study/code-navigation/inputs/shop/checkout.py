from shop import pricing


def finalize(order):
    discount = pricing.calc_discount(order, order.get("rate", 0.1))
    tax = pricing.calc_tax(order)
    return order["total"] - discount + tax
