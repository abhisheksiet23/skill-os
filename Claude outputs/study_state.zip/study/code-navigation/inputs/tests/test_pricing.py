from shop.pricing import calc_discount


def test_discount():
    assert calc_discount({"total": 100}, 0.1) == 10.0
