Ground truth (line numbers in inputs/):
- shop/checkout.py:5 direct call pricing.calc_discount(order, ...) -> affected
- shop/registry.py:6 dynamic dispatch getattr(pricing, "calc_" + kind) with kind='discount' -> affected, not found by plain text search for "calc_discount"
- config/rules.yaml:4 function: calc_discount (string reference; arg list [order, 0.15] uses rate) -> affected
- tests/test_pricing.py:1 import and :5 call -> affected (test must change)
- shop/pricing.py:1 definition itself.
- NOT affected: calc_discount_legacy (pricing.py:6, reports.py:1 and :5) and calc_tax. A good answer says so explicitly (name collision).
Expectations: finds all 5 locations incl. the dynamic and YAML ones, excludes legacy, states completeness limits (reflection/dynamic names/config; other callers like external repos cannot be ruled out), says which tooling (semantic navigation not available vs grep) was used honestly; no modification of repo.
