# Expense approval — collected notes (Finance ops project)
**Email from Priya (Finance Director), 3 Mar:** "Managers can approve expenses up to $500. Anything above goes to Finance."
**Email from Dan (Controller), 19 Mar:** "To be clear, anything over $200 needs Finance sign-off, per the new audit rules."
**Policy extract (HR handbook, 2024):** Approval limits depend on employee grade: G1-G3 manager approves; G4+ department head approves. Amounts are not mentioned.
**Legacy system behaviour (observed by support):** claims under $50 are auto-approved; nobody has confirmed this is intended.
**Ops request:** "Claims by a manager about their own expenses should not be approved by themselves." Who approves them is not stated.
**Scope note:** The payroll export format must not change.
**Pain points (from 4 interviews):** approvers miss emails; employees don't know claim status; Finance re-keys approved claims into the ledger.
Not provided: volumes, currencies, receipt rules, multi-level approval, SLA.
