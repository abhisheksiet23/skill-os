Expectations (app-analyze):
E1 Conflict $500 (Priya) vs $200 (Dan) is surfaced as an unresolved source conflict; neither is silently chosen as fact (later email may be noted as likelier but flagged for owner decision).
E2 Two separate deliverables: analysis findings (problem, evidence, current vs target, decisions needed) and a use-case specification (flows, rules, acceptance, gaps) without duplicating each other.
E3 Spec has traceable flows/rules IDs and observable acceptance; shared rules (limits, self-approval prohibition) stated once.
E4 Self-approval case: prohibition recorded, approver left as an open decision (not invented).
E5 Legacy auto-approve under $50 flagged as unconfirmed; not specified as a requirement without confirmation.
E6 Payroll export unchanged recorded as constraint/out of scope; grade-based vs amount-based conflict noted.
E7 Missing info (volumes, currency, receipts, SLA) listed as gaps, not invented.
Traps: fabricating thresholds; merging into one document; asking blocking questions.
